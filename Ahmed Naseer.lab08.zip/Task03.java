/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bstdemo;

/**
 *
 * @author an_ki
 */


import java.util.Scanner;

// Node class representing an individual student record
class StudentNode {
    int studentId;
    String studentName;
    StudentNode left, right;

    public StudentNode(int studentId, String studentName) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.left = this.right = null;
    }
}

// Binary Search Tree specialized for Student Records
class StudentBST {
    StudentNode root;

    public StudentBST() {
        root = null;
    }

    // 1. Insert a new student record
    public void insert(int id, String name) {
        root = insertRec(root, id, name);
    }

    private StudentNode insertRec(StudentNode root, int id, String name) {
        if (root == null) {
            return new StudentNode(id, name);
        }
        if (id < root.studentId) {
            root.left = insertRec(root.left, id, name);
        } else if (id > root.studentId) {
            root.right = insertRec(root.right, id, name);
        } else {
            System.out.println("Student ID " + id + " already exists. Updating name.");
            root.studentName = name;
        }
        return root;
    }

    // 2. Search for a student using Student ID
    public StudentNode search(int id) {
        return searchRec(root, id);
    }

    private StudentNode searchRec(StudentNode root, int id) {
        if (root == null || root.studentId == id) {
            return root;
        }
        if (id < root.studentId) {
            return searchRec(root.left, id);
        }
        return searchRec(root.right, id);
    }

    // 3. Delete a student record using Student ID
    public void delete(int id) {
        root = deleteRec(root, id);
    }

    private StudentNode deleteRec(StudentNode root, int id) {
        if (root == null) {
            return null;
        }

        if (id < root.studentId) {
            root.left = deleteRec(root.left, id);
        } else if (id > root.studentId) {
            root.right = deleteRec(root.right, id);
        } else {
            // Case 1: Node with no child or only one child
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            // Case 2: Node with two children
            // Get the inorder successor (smallest value in the right subtree)
            StudentNode successor = findMinNode(root.right);
            root.studentId = successor.studentId;
            root.studentName = successor.studentName;

            // Delete the inorder successor from the right subtree
            root.right = deleteRec(root.right, successor.studentId);
        }
        return root;
    }

    private StudentNode findMinNode(StudentNode root) {
        StudentNode current = root;
        while (current.left != null) {
            current = current.left;
        }
        return current;
    }

    // 4. Display all student records in ascending order of Student ID (Inorder)
    public void displayInOrder() {
        if (root == null) {
            System.out.println("No student records found in the system.");
            return;
        }
        System.out.println("\n----------------------------------------");
        System.out.printf("%-15s | %-20s\n", "Student ID", "Student Name");
        System.out.println("----------------------------------------");
        displayInOrderRec(root);
        System.out.println("----------------------------------------");
    }

    private void displayInOrderRec(StudentNode root) {
        if (root != null) {
            displayInOrderRec(root.left);
            System.out.printf("%-15d | %-20s\n", root.studentId, root.studentName);
            displayInOrderRec(root.right);
        }
    }

    // 5. Display the total number of students stored in the BST
    public int getCount() {
        return countRec(root);
    }

    private int countRec(StudentNode root) {
        if (root == null) {
            return 0;
        }
        return 1 + countRec(root.left) + countRec(root.right);
    }
}

// Menu-driven Program Class
public class Task03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentBST bst = new StudentBST();
        int choice;

        do {
            System.out.println("\n=== Student Record Management System ===");
            System.out.println("1. Insert a new student record");
            System.out.println("2. Search for a student using Student ID");
            System.out.println("3. Delete a student record using Student ID");
            System.out.println("4. Display all student records (Ascending Order)");
            System.out.println("5. Display total number of students");
            System.out.println("6. Exit");
            System.out.print("Enter your choice (1-6): ");

            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number between 1 and 6.");
                scanner.next();
            }
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID (integer): ");
                    while (!scanner.hasNextInt()) {
                        System.out.println("Invalid ID. Please enter a valid integer ID:");
                        scanner.next();
                    }
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    System.out.print("Enter Student Name: ");
                    String name = scanner.nextLine();

                    bst.insert(id, name);
                    System.out.println("Student record inserted successfully!");
                    break;

                case 2:
                    System.out.print("Enter Student ID to search: ");
                    int searchId = scanner.nextInt();
                    StudentNode found = bst.search(searchId);
                    if (found != null) {
                        System.out.println("Record Found -> ID: " + found.studentId + ", Name: " + found.studentName);
                    } else {
                        System.out.println("Student with ID " + searchId + " not found.");
                    }
                    break;

                case 3:
                    System.out.print("Enter Student ID to delete: ");
                    int deleteId = scanner.nextInt();
                    if (bst.search(deleteId) != null) {
                        bst.delete(deleteId);
                        System.out.println("Student record deleted successfully.");
                    } else {
                        System.out.println("Student with ID " + deleteId + " not found.");
                    }
                    break;

                case 4:
                    bst.displayInOrder();
                    break;

                case 5:
                    System.out.println("Total number of students stored: " + bst.getCount());
                    break;

                case 6:
                    System.out.println("Exiting Student Record System. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice! Please choose an option between 1 and 6.");
            }
        } while (choice != 6);

        scanner.close();
    }
}