/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bstdemo;

/**
 *
 * @author an_ki
 */

class Node {
    int data;
    Node left, right;

    public Node(int item) {
        data = item;
        left = right = null;
    }
}

class BinarySearchTree {
    Node root;

    public BinarySearchTree() {
        root = null;
    }

    // Insert a value into the BST
    public void insert(int value) {
        root = insertRec(root, value);
    }

    private Node insertRec(Node root, int value) {
        if (root == null) {
            root = new Node(value);
            return root;
        }
        if (value < root.data) {
            root.left = insertRec(root.left, value);
        } else if (value > root.data) {
            root.right = insertRec(root.right, value);
        }
        return root;
    }

    // Search for a value in the BST
    public boolean search(int key) {
        return searchRec(root, key) != null;
    }

    private Node searchRec(Node root, int key) {
        if (root == null || root.data == key) {
            return root;
        }
        if (key < root.data) {
            return searchRec(root.left, key);
        }
        return searchRec(root.right, key);
    }

    // Delete a value from the BST
    public void delete(int key) {
        root = deleteRec(root, key);
    }

    private Node deleteRec(Node root, int key) {
        if (root == null) {
            return root;
        }

        // Traverse down the tree to find the node
        if (key < root.data) {
            root.left = deleteRec(root.left, key);
        } else if (key > root.data) {
            root.right = deleteRec(root.right, key);
        } else {
            // Node with only one child or no child
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            // Node with two children: Get the inorder successor (smallest in the right subtree)
            root.data = minValue(root.right);

            // Delete the inorder successor
            root.right = deleteRec(root.right, root.data);
        }
        return root;
    }

    private int minValue(Node root) {
        int minv = root.data;
        while (root.left != null) {
            minv = root.left.data;
            root = root.left;
        }
        return minv;
    }

    // Inorder Traversal (Left, Root, Right)
    public void inorder() {
        inorderRec(root);
        System.out.println();
    }

    private void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.print(root.data + " ");
            inorderRec(root.right);
        }
    }
}

public class Task2{
    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
        int[] values = {45, 25, 65, 15, 35, 55, 75, 10, 20};

        // Construct BST
        for (int val : values) {
            bst.insert(val);
        }

        // 1. Search for value 35 and 100
        System.out.println("Searching for 35: " + (bst.search(35) ? "Found" : "Not Found"));
        System.out.println("Searching for 100: " + (bst.search(100) ? "Found" : "Not Found"));
        System.out.println();

        // 2. Delete Leaf Node 10
        bst.delete(10);
        System.out.print("Inorder after deleting 10 (Leaf): ");
        bst.inorder();

        // 3. Delete Node 25
        bst.delete(25);
        System.out.print("Inorder after deleting 25: ");
        bst.inorder();

        // 4. Delete Root Node 45 (Two children)
        bst.delete(45);
        System.out.print("Inorder after deleting Root 45: ");
        bst.inorder();
    }
}