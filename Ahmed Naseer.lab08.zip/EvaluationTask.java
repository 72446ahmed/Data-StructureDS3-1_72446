/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bstdemo;

/**
 *
 * @author an_ki
 */


import java.util.Scanner;

class EvalNode {
    int data;
    EvalNode left, right;

    public EvalNode(int item) {
        data = item;
        left = right = null;
    }
}

class EvaluationBST {
    EvalNode root;

    public EvaluationBST() {
        root = null;
    }

    // 1. Insert multiple values and prevent duplicates
    public void insert(int value) {
        root = insertRec(root, value);
    }

    private EvalNode insertRec(EvalNode root, int value) {
        if (root == null) {
            System.out.println("Value " + value + " inserted successfully.");
            return new EvalNode(value);
        }
        if (value < root.data) {
            root.left = insertRec(root.left, value);
        } else if (value > root.data) {
            root.right = insertRec(root.right, value);
        } else {
            System.out.println("Duplicate value (" + value + ") detected! Duplicates are not allowed.");
        }
        return root;
    }

    // 2. Search for a particular value
    public boolean search(int key) {
        return searchRec(root, key) != null;
    }

    private EvalNode searchRec(EvalNode root, int key) {
        if (root == null || root.data == key) {
            return root;
        }
        if (key < root.data) {
            return searchRec(root.left, key);
        }
        return searchRec(root.right, key);
    }

    // 3. Traversals (Inorder, Preorder, Postorder)
    public void inorder() {
        if (root == null) {
            System.out.println("Tree is empty.");
            return;
        }
        inorderRec(root);
        System.out.println();
    }

    private void inorderRec(EvalNode root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.print(root.data + " ");
            inorderRec(root.right);
        }
    }

    public void preorder() {
        if (root == null) {
            System.out.println("Tree is empty.");
            return;
        }
        preorderRec(root);
        System.out.println();
    }

    private void preorderRec(EvalNode root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preorderRec(root.left);
            preorderRec(root.right);
        }
    }

    public void postorder() {
        if (root == null) {
            System.out.println("Tree is empty.");
            return;
        }
        postorderRec(root);
        System.out.println();
    }

    private void postorderRec(EvalNode root) {
        if (root != null) {
            postorderRec(root.left);
            postorderRec(root.right);
            System.out.print(root.data + " ");
        }
    }

    // 4. Find Minimum Value
    public int findMin() {
        EvalNode current = root;
        while (current.left != null) {
            current = current.left;
        }
        return current.data;
    }

    // 5. Find Maximum Value
    public int findMax() {
        EvalNode current = root;
        while (current.right != null) {
            current = current.right;
        }
        return current.data;
    }

    // 6. Delete a specified node
    public void delete(int key) {
        root = deleteRec(root, key);
    }

    private EvalNode deleteRec(EvalNode root, int key) {
        if (root == null) {
            return null;
        }

        if (key < root.data) {
            root.left = deleteRec(root.left, key);
        } else if (key > root.data) {
            root.right = deleteRec(root.right, key);
        } else {
            // Node with no child or one child
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            // Node with two children: Get inorder successor
            root.data = findMinValue(root.right);
            root.right = deleteRec(root.right, root.data);
        }
        return root;
    }

    private int findMinValue(EvalNode root) {
        int minv = root.data;
        while (root.left != null) {
            minv = root.left.data;
            root = root.left;
        }
        return minv;
    }
}

public class EvaluationTask {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EvaluationBST bst = new EvaluationBST();
        int choice;

        do {
            System.out.println("\n=== Evaluation Task: BST Menu ===");
            System.out.println("1. Insert an integer value (Duplicates prevented)");
            System.out.println("2. Search for a value");
            System.out.println("3. Display Inorder Traversal");
            System.out.println("4. Display Preorder Traversal");
            System.out.println("5. Display Postorder Traversal");
            System.out.println("6. Find Minimum and Maximum values");
            System.out.println("7. Delete a specified node");
            System.out.println("8. Exit");
            System.out.print("Enter your choice (1-8): ");

            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a valid number between 1 and 8.");
                scanner.next();
            }
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter integer value to insert: ");
                    while (!scanner.hasNextInt()) {
                        System.out.println("Invalid integer. Try again:");
                        scanner.next();
                    }
                    int val = scanner.nextInt();
                    bst.insert(val);
                    break;

                case 2:
                    if (bst.root == null) {
                        System.out.println("The tree is currently empty. Cannot search.");
                        break;
                    }
                    System.out.print("Enter value to search: ");
                    int searchVal = scanner.nextInt();
                    boolean found = bst.search(searchVal);
                    if (found) {
                        System.out.println("Success: Value " + searchVal + " exists in the BST.");
                    } else {
                        System.out.println("Not Found: Value " + searchVal + " is not in the BST.");
                    }
                    break;

                case 3:
                    System.out.print("Inorder Traversal: ");
                    bst.inorder();
                    break;

                case 4:
                    System.out.print("Preorder Traversal: ");
                    bst.preorder();
                    break;

                case 5:
                    System.out.print("Postorder Traversal: ");
                    bst.postorder();
                    break;

                case 6:
                    if (bst.root == null) {
                        System.out.println("The tree is currently empty.");
                    } else {
                        System.out.println("Minimum Value: " + bst.findMin());
                        System.out.println("Maximum Value: " + bst.findMax());
                    }
                    break;

                case 7:
                    if (bst.root == null) {
                        System.out.println("The tree is currently empty. Nothing to delete.");
                        break;
                    }
                    System.out.print("Enter value to delete: ");
                    int delVal = scanner.nextInt();
                    if (bst.search(delVal)) {
                        bst.delete(delVal);
                        System.out.println("Node " + delVal + " deleted successfully.");
                        System.out.print("Updated BST (Inorder Traversal): ");
                        bst.inorder();
                    } else {
                        System.out.println("Value " + delVal + " not found in the tree.");
                    }
                    break;

                case 8:
                    System.out.println("Exiting Evaluation Program. Good luck!");
                    break;

                default:
                    System.out.println("Invalid choice! Please choose an option between 1 and 8.");
            }
        } while (choice != 8);

        scanner.close();
    }
}