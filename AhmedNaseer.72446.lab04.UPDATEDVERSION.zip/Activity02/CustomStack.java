/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity02;

/**
 *
 * @author an_ki
 */
public class CustomStack {
    private int[] stack;
    private int top;
    private int capacity;
    public CustomStack(int size) {
        capacity = size;
        stack = new int[capacity];
        top = -1; 
    }
    public void push(int value) {
        if (top == capacity - 1) {
            System.out.println("Stack Overflow! Cannot push " + value + ". Stack is full.");
            return;
        }
        stack[++top] = value;
        System.out.println("Pushed: " + value);
    }
    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow! Cannot pop from an empty stack.");
            return -1;
        }
        int poppedValue = stack[top--];
        System.out.println("Popped: " + poppedValue);
        return poppedValue;
    }
    public int peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty! Nothing to peek.");
            return -1;
        }
        System.out.println("Top element (Peek): " + stack[top]);
        return stack[top];
    }
    public void display() {
        if (isEmpty()) {
            System.out.println("Stack is empty.");
            return;
        }
        System.out.print("Current Stack (top to bottom): ");
        for (int i = top; i >= 0; i--) {
            System.out.print(stack[i] + " ");
        }
        System.out.println();
    }
    public boolean isEmpty() {
        return top == -1;
    }

    public static void main(String[] args) {
        CustomStack myStack = new CustomStack(5);

        System.out.println("--- Executing Required Sequence ---");

        myStack.push(10);

        myStack.push(20);

        myStack.push(30);

        myStack.display();

        myStack.peek();

        myStack.pop();

        myStack.display();

        System.out.println("\n--- Additional Demonstration: Overflow & Underflow ---");

        myStack.push(40);
        myStack.push(50);
        myStack.push(60);
        myStack.push(70); 

        myStack.pop();
        myStack.pop();
        myStack.pop();
        myStack.pop();
        myStack.pop(); 
        myStack.pop();
    }
}