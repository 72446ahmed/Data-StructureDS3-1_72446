/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity01;

/**
 *
 * @author an_ki
 */
import java.util.Scanner;

public class BinarySearch {
    public static int binarySearch(int[] arr, int target) {
        int low = 0;
        int high = arr.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (arr[mid] == target) {
                return mid; 
            }

            if (arr[mid] < target) {
                low = mid + 1; 
            } else {
                high = mid - 1;
            }
        }

        return -1; 
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int[] binaryArray = {12, 23, 34, 45, 56, 78, 89};

        System.out.print("Enter a target value to search for in Binary Search array: ");
        int target = input.nextInt();

        System.out.println("\n==========================================");
        System.out.println("          BINARY SEARCH RESULT            ");
        System.out.println("==========================================");
        System.out.println("Target Value: " + target);

        int result = binarySearch(binaryArray, target);

        if (result != -1) {
            System.out.println("Result: Found at index position " + result);
        } else {
            System.out.println("Result: Target value not found (-1)");
        }
        System.out.println("==========================================");
    }
}