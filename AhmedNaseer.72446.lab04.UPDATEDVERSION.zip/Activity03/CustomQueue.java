/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity03;

/**
 *
 * @author an_ki
 */
public class CustomQueue {
    private int[] queue;
    private int front;
    private int rear;
    private int capacity;
    private int count;
    public CustomQueue(int size) {
        capacity = size;
        queue = new int[capacity];
        front = 0;
        rear = -1;
        count = 0;
    }
    public void enqueue(int value) {
        if (isFull()) {
            System.out.println("Queue Overflow! Cannot enqueue " + value + ". Queue is full.");
            return;
        }
        rear = (rear + 1) % capacity;
        queue[rear] = value;
        count++;
        System.out.println("Enqueued: " + value);
    }
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue Underflow! Cannot dequeue from an empty queue.");
            return -1;
        }
        int removedValue = queue[front];
        front = (front + 1) % capacity;
        count--;
        System.out.println("Dequeued: " + removedValue);
        return removedValue;
    }
    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty! Nothing to peek.");
            return -1;
        }
        System.out.println("Front element (Peek): " + queue[front]);
        return queue[front];
    }
    public void display() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }
        System.out.print("Current Queue (front to rear): ");
        for (int i = 0; i < count; i++) {
            int index = (front + i) % capacity;
            System.out.print(queue[index] + " ");
        }
        System.out.println();
    }

    // Helper methods
    public boolean isEmpty() {
        return count == 0;
    }

    public boolean isFull() {
        return count == capacity;
    }

    public static void main(String[] args) {
        CustomQueue myQueue = new CustomQueue(5);

        System.out.println("--- Executing Required Sequence ---");
        myQueue.enqueue(10);
        myQueue.enqueue(20);
        myQueue.enqueue(30);
        myQueue.display();
        myQueue.peek();
        myQueue.dequeue();
        myQueue.display();

        System.out.println("\n--- Additional Demonstration: Overflow & Underflow ---");
        myQueue.enqueue(40);
        myQueue.enqueue(50);
        myQueue.enqueue(60);

        myQueue.enqueue(70);
        myQueue.dequeue();
        myQueue.dequeue();
        myQueue.dequeue();
        myQueue.dequeue();
        myQueue.dequeue(); 
        myQueue.dequeue();
    }
}
