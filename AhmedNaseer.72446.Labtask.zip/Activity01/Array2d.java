/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity01;

/**
 *
 * @author an_ki
 */
import java.util.Scanner;

public class Array2d {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of rows: ");
        int rows = input.nextInt();
        System.out.print("Enter number of columns: ");
        int cols = input.nextInt();

        int[][] matrix = new int[rows][cols];

        System.out.println("\n--- Enter Array Elements ---");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print("Element [" + i + "][" + j + "]: ");
                matrix[i][j] = input.nextInt();
            }
        }

        System.out.println("\n--- 2D Array Elements ---");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(matrix[i][j] + "\t");
            }
            System.out.println();
        }

        int totalSum = 0;
        int max = matrix[0][0];
        int min = matrix[0][0];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int val = matrix[i][j];
                totalSum += val;
                if (val > max) max = val;
                if (val < min) min = val;
            }
        }
        double totalAvg = (double) totalSum / (rows * cols);

        System.out.println("\n--- Global Statistics ---");
        System.out.println("Total Sum: " + totalSum);
        System.out.println("Average: " + totalAvg);
        System.out.println("Maximum: " + max);
        System.out.println("Minimum: " + min);

        System.out.println("\n--- Row Sums ---");
        for (int i = 0; i < rows; i++) {
            int rowSum = 0;
            for (int j = 0; j < cols; j++) {
                rowSum += matrix[i][j];
            }
            System.out.println("Sum of Row " + i + ": " + rowSum);
        }

        System.out.println("\n--- Column Sums ---");
        for (int j = 0; j < cols; j++) {
            int colSum = 0;
            for (int i = 0; i < rows; i++) {
                colSum += matrix[i][j];
            }
            System.out.println("Sum of Column " + j + ": " + colSum);
        }
    }
}