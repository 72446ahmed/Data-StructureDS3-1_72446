/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity01;

/**
 *
 * @author an_ki
 */
import java.util.Scanner;

public class Array3d {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of layers: ");
        int layers = input.nextInt();
        System.out.print("Enter number of rows: ");
        int rows = input.nextInt();
        System.out.print("Enter number of columns: ");
        int cols = input.nextInt();

        int[][][] array3D = new int[layers][rows][cols];

        System.out.println("\n--- Enter 3D Array Elements ---");
        for (int l = 0; l < layers; l++) {
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    System.out.print("Element [Layer " + l + "][Row " + r + "][Col " + c + "]: ");
                    array3D[l][r][c] = input.nextInt();
                }
            }
        }
        System.out.println("\n--- Displaying 3D Array ---");
        for (int l = 0; l < layers; l++) {
            System.out.println("Layer " + l + ":");
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    System.out.print(array3D[l][r][c] + "\t");
                }
                System.out.println();
            }
            System.out.println();
        }
        int totalSum = 0;
        int max = array3D[0][0][0];
        int min = array3D[0][0][0];

        for (int l = 0; l < layers; l++) {
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    int val = array3D[l][r][c];
                    totalSum += val;
                    if (val > max) max = val;
                    if (val < min) min = val;
                }
            }
        }
        double average = (double) totalSum / (layers * rows * cols);
        System.out.println("--- Global Statistics ---");
        System.out.println("Total Sum: " + totalSum);
        System.out.println("Average: " + average);
        System.out.println("Maximum: " + max);
        System.out.println("Minimum: " + min);

        System.out.println("\n--- Layer Sums ---");
        for (int l = 0; l < layers; l++) {
            int layerSum = 0;
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    layerSum += array3D[l][r][c];
                }
            }
            System.out.println("Sum of Layer " + l + ": " + layerSum);
        }
        System.out.println("\n--- Search Operation ---");
        System.out.print("Enter value to search for: ");
        int target = input.nextInt();
        boolean found = false;

        for (int l = 0; l < layers; l++) {
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if (array3D[l][r][c] == target) {
                        System.out.println("Value " + target + " found at: Layer " + l + ", Row " + r + ", Column " + c);
                        found = true;
                    }
                }
            }
        }

        if (!found) {
            System.out.println("Value " + target + " was not found in the 3D array.");
        }
    }
}