/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity01;

/**
 *
 * @author an_ki
 */
import java.util.Scanner;

public class Array1D {
    public static void main(String[] args) {
        int[] originalArray = {45, 12, 78, 23, 9, 56, 34, 89, 17, 63};

        System.out.println("--- A. Traversal ---");
        System.out.print("Array elements: ");
        for (int i = 0; i < originalArray.length; i++) {
            System.out.print(originalArray[i] + " ");
        }
        System.out.println();

        System.out.println("\n--- B. Statistics ---");
        int sum = 0;
        int max = originalArray[0];
        int min = originalArray[0];

        for (int val : originalArray) {
            sum += val;
            if (val > max) max = val;
            if (val < min) min = val;
        }
        double average = (double) sum / originalArray.length;

        System.out.println("Sum: " + sum);
        System.out.println("Average: " + average);
        System.out.println("Maximum: " + max);
        System.out.println("Minimum: " + min);

        System.out.println("\n--- C. Insertion ---");
        Scanner input = new Scanner(System.in);
        System.out.print("Enter index to insert at (0 to " + originalArray.length + "): ");
        int insertIndex = input.nextInt();
        System.out.print("Enter new value to insert: ");
        int newValue = input.nextInt();

        int[] insertedArray = new int[originalArray.length + 1];
        for (int i = 0, j = 0; i < insertedArray.length; i++) {
            if (i == insertIndex) {
                insertedArray[i] = newValue;
            } else {
                insertedArray[i] = originalArray[j++];
            }
        }

        System.out.print("Array after insertion: ");
        for (int val : insertedArray) {
            System.out.print(val + " ");
        }
        System.out.println();

        // D. Deletion
        System.out.println("\n--- D. Deletion ---");
        System.out.print("Enter index to delete from original array (0 to " + (originalArray.length - 1) + "): ");
        int deleteIndex = input.nextInt();

        // New array with size - 1 for deletion
        int[] deletedArray = new int[originalArray.length - 1];
        for (int i = 0, j = 0; i < originalArray.length; i++) {
            if (i == deleteIndex) {
                continue; // Skip the target element
            }
            deletedArray[j++] = originalArray[i];
        }

        System.out.print("Array after deletion: ");
        for (int val : deletedArray) {
            System.out.print(val + " ");
        }
        System.out.println();
    }
}