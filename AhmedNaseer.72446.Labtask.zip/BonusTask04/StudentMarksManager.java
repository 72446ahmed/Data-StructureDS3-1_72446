/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BonusTask04;

/**
 *
 * @author an_ki
 */
import java.util.Arrays;
import java.util.Scanner;

class MarkNode {
    int mark;
    MarkNode next;

    MarkNode(int mark) {
        this.mark = mark;
        this.next = null;
    }
}
public class StudentMarksManager {
    private MarkNode head;
    public void insertAtEnd(int mark) {
        MarkNode newNode = new MarkNode(mark);
        if (head == null) {
            head = newNode;
            return;
        }
        MarkNode current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }
    public void insertAtBeginning(int mark) {
        MarkNode newNode = new MarkNode(mark);
        newNode.next = head;
        head = newNode;
    }
    public void deleteMark(int target) {
        if (head == null) {
            System.out.println("List is empty. Cannot delete.");
            return;
        }

        if (head.mark == target) {
            head = head.next;
            System.out.println("Successfully deleted mark: " + target);
            return;
        }

        MarkNode current = head;
        while (current.next != null && current.next.mark != target) {
            current = current.next;
        }

        if (current.next == null) {
            System.out.println("Mark " + target + " not found in the list.");
        } else {
            current.next = current.next.next;
            System.out.println("Successfully deleted mark: " + target);
        }
    }
    public void displayLinkedList() {
        if (head == null) {
            System.out.println("Linked List is empty.");
            return;
        }
        MarkNode current = head;
        while (current != null) {
            System.out.print(current.mark + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        StudentMarksManager listManager = new StudentMarksManager();

        // 1. Store initial student marks in an array
        int[] marksArray = {85, 62, 94, 47, 73, 88, 55};

        System.out.println("==================================================");
        System.out.println("        STUDENT MARKS MANAGER DEMO                ");
        System.out.println("==================================================");

        // Display array
        System.out.print("Initial Marks Array: ");
        System.out.println(Arrays.toString(marksArray));
        int sum = 0;
        int max = marksArray[0];
        int min = marksArray[0];

        for (int mark : marksArray) {
            sum += mark;
            if (mark > max) max = mark;
            if (mark < min) min = mark;
        }
        double average = (double) sum / marksArray.length;

        System.out.println("\n--- Array Statistics ---");
        System.out.println("Maximum Mark: " + max);
        System.out.println("Minimum Mark: " + min);
        System.out.printf("Average Mark: %.2f\n", average);
        int[] sortedMarksArray = marksArray.clone();
        bubbleSort(sortedMarksArray);
        System.out.println("\n--- Array Sorting ---");
        System.out.print("Sorted Marks Array (Ascending): ");
        System.out.println(Arrays.toString(sortedMarksArray));
        for (int mark : marksArray) {
            listManager.insertAtEnd(mark);
        }

        System.out.println("\n--- Initial Singly Linked List ---");
        listManager.displayLinkedList();
        System.out.println("\n--- Inserting New Mark (99) at Beginning ---");
        listManager.insertAtBeginning(99);
        listManager.displayLinkedList();
        System.out.println("\n--- Deleting Mark (47) from Linked List ---");
        listManager.deleteMark(47);
        listManager.displayLinkedList();
        System.out.println("\n==================================================");
        System.out.println("              FINAL SUMMARY CONTENTS              ");
        System.out.println("==================================================");
        System.out.print("Final Sorted Array:       ");
        System.out.println(Arrays.toString(sortedMarksArray));
        System.out.print("Final Singly Linked List: ");
        listManager.displayLinkedList();
        System.out.println("==================================================");
    }
}