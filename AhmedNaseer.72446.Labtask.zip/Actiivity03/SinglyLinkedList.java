/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actiivity03;

/**
 *
 * @author an_ki
 */
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}
public class SinglyLinkedList {
    private Node head;
    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }
    public void insertAtBeginning(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }
    public void insertAtEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }
    public boolean search(int target) {
        Node current = head;
        int position = 0;
        while (current != null) {
            if (current.data == target) {
                System.out.println("Value " + target + " found at node position " + position);
                return true;
            }
            current = current.next;
            position++;
        }
        System.out.println("Value " + target + " not found in the list.");
        return false;
    }
    public void deleteByValue(int target) {
        if (head == null) {
            System.out.println("Cannot delete from an empty list.");
            return;
        }
        if (head.data == target) {
            head = head.next;
            System.out.println("Deleted " + target + " from head position.");
            return;
        }
        Node current = head;
        while (current.next != null && current.next.data != target) {
            current = current.next;
        }

        if (current.next == null) {
            System.out.println("Value " + target + " not found for deletion.");
        } else {
            current.next = current.next.next; // Bypass deleted node
            System.out.println("Deleted value " + target + " from list.");
        }
    }
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();

        list.insertAtEnd(10);
        list.insertAtEnd(20);
        list.insertAtEnd(30);
        list.insertAtEnd(40);
        list.insertAtEnd(50);
        System.out.println("--- A. Initial Linked List ---");
        list.display();
        System.out.println("\n--- B. Insert 5 at Beginning ---");
        list.insertAtBeginning(5);
        list.display();
        System.out.println("\n--- C. Insert 60 at End ---");
        list.insertAtEnd(60);
        list.display();
        System.out.println("\n--- D. Search Operations ---");
        list.search(30);
        list.search(99);
        System.out.println("\n--- E. Delete Operation (Removing 30) ---");
        list.deleteByValue(30);

        System.out.println("\n--- F. Final Linked List ---");
        list.display();
    }
}