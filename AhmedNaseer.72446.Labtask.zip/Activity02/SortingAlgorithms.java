/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity02;

/**
 *
 * @author an_ki
 */
import java.util.Arrays;

public class SortingAlgorithms {
    public static void printArray(int[] arr) {
        for (int val : arr) {
            System.out.print(val + " ");
        }
        System.out.println();
    }
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    // Swap adjacent elements
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
    public static void selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            int temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
    }
    public static void insertionSort(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }
    public static void main(String[] args) {
        int[] originalArray = {64, 25, 12, 22, 11, 90, 34};

        System.out.println("Original Array: " + Arrays.toString(originalArray));
        System.out.println("=================================================");

        int[] bubbleArray = originalArray.clone();
        bubbleSort(bubbleArray);
        System.out.print("Bubble Sort Result:    ");
        printArray(bubbleArray);

        int[] selectionArray = originalArray.clone();
        selectionSort(selectionArray);
        System.out.print("Selection Sort Result: ");
        printArray(selectionArray);

        int[] insertionArray = originalArray.clone();
        insertionSort(insertionArray);
        System.out.print("Insertion Sort Result: ");
        printArray(insertionArray);
    }
}