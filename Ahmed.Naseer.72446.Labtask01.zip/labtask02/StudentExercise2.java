/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask02;

/**
 *
 * @author an_ki
 */
import java.util.Scanner;

public class StudentExercise2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter marks: ");
        int marks = input.nextInt();

        System.out.print("Enter attendance percentage: ");
        double attendance = input.nextDouble();

        // Compound condition requiring both conditions to be true
        if (marks >= 50 && attendance >= 75.0) {
            System.out.println("Eligible for Exam");
        } else {
            System.out.println("Not Eligible for Exam");
        }
    }
}