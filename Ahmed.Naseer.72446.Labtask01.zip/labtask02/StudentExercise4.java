/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask02;

/**
 *
 * @author an_ki
 */
import java.util.Scanner;

public class StudentExercise4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter option (1 or 2): ");
        int option = input.nextInt();

        /*
         * DEMONSTRATION OF FALL-THROUGH:
         * The 'break' is omitted from Case 1. If option = 1, execution falls
         * straight into Case 2 without checking if option == 2.
         */
        switch (option) {
            case 1:
                System.out.println("Executed Case 1");
                // break is deliberately omitted here
            case 2:
                System.out.println("Executed Case 2");
                break;
            default:
                System.out.println("Executed Default");
        }
    }
}
