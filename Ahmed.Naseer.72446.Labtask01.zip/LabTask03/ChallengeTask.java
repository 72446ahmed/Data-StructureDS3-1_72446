/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask03;

/**
 *
 * @author an_ki
 */
import java.util.Scanner;

public class ChallengeTask {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of courses (n): ");
        int n = input.nextInt();

        double[] marks = new double[n];

        // Input marks
        for (int i = 0; i < n; i++) {
            System.out.print("Enter mark for course " + (i + 1) + ": ");
            marks[i] = input.nextDouble();
        }

        // Calculate sum and maximum
        double sum = 0;
        double max = marks[0];

        for (double mark : marks) {
            sum += mark;
            if (mark > max) {
                max = mark;
            }
        }

        // Use for-each loop to count marks >= 50
        int passCount = 0;
        for (double mark : marks) {
            if (mark >= 50.0) {
                passCount++;
            }
        }

        // Display results
        System.out.println("===============================");
        System.out.println("Total Marks Sum: " + sum);
        System.out.println("Maximum Mark:    " + max);
        System.out.println("Courses Passed (>= 50): " + passCount);
        System.out.println("===============================");
    }
}