/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask03;

/**
 *
 * @author an_ki
 */
public class Exercise4 {
    public static void main(String[] args) {
        double[] numbers = {12.5, 45.2, 89.0, 23.8, 67.4};

        double max = numbers[0];
        for (double num : numbers) {
            if (num > max) {
                max = num;
            }
        }

        System.out.println("Maximum value in array = " + max);
    }
}
