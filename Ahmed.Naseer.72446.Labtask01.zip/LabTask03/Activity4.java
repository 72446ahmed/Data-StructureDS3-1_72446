/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask03;

/**
 *
 * @author an_ki
 */
public class Activity4 {
    public static void main(String[] args) {
        double[] values = {2.5, 3.0, 4.5};
        double sum = 0;

        for (double value : values) {
            sum += value;
        }

        System.out.println("Sum = " + sum);
    }
}