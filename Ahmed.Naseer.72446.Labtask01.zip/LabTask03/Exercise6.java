/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask03;

/**
 *
 * @author an_ki
 */
import java.util.Scanner;

public class Exercise6 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        while (true) {
            System.out.print("Enter a number (-1 to stop): ");
            int value = input.nextInt();

            if (value == -1) {
                System.out.println("Termination signal received. Exiting loop.");
                break;
            }

            System.out.println("You entered: " + value);
        }
    }
}
