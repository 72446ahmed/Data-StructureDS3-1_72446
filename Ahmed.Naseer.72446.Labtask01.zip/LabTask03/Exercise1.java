/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask03;

/**
 *
 * @author an_ki
 */
public class Exercise1 {
    public static void main(String[] args) {
        int count = 10;

        while (count >= 1) {
            System.out.println(count);
            count--;
        }
    }
}
