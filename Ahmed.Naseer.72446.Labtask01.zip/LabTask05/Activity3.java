/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask05;

/**
 *
 * @author an_ki
 */
class ExtendedCounter {
    private int count;

    // Default constructor
    public ExtendedCounter() {
        count = 0;
    }

    // Overloaded constructor accepting initial value
    public ExtendedCounter(int initialValue) {
        count = initialValue;
    }

    public int getCount() {
        return count;
    }

    public void increment() {
        count++;
    }

    // New decrement method
    public void decrement() {
        count--;
    }
}

public class Activity3 {
    public static void main(String[] args) {
        ExtendedCounter c = new ExtendedCounter(10);
        c.increment();
        c.decrement();
        c.decrement();
        System.out.println("Final Count: " + c.getCount());
    }
}