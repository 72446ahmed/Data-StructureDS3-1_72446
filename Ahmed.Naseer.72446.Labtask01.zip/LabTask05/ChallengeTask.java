/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask05;

/**
 *
 * @author an_ki
 */
class BankAccount {
    private String accountHolderName;
    private double balance;

    public BankAccount(String accountHolderName, double initialBalance) {
        this.accountHolderName = accountHolderName;
        if (initialBalance >= 0) {
            this.balance = initialBalance;
        } else {
            this.balance = 0.0;
        }
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited $" + amount + ". New Balance: $" + balance);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid withdrawal amount.");
        } else if (amount > balance) {
            System.out.println("Withdrawal rejected: Insufficient funds. Balance remains: $" + balance);
        } else {
            balance -= amount;
            System.out.println("Withdrew $" + amount + ". New Balance: $" + balance);
        }
    }
}

public class ChallengeTask {
    public static void main(String[] args) {
        BankAccount account = new BankAccount("Alice Smith", 500.0);

        System.out.println("Account Holder Balance: $" + account.getBalance());
        account.deposit(200.0);
        account.withdraw(1000.0); // Should be prevented
        account.withdraw(300.0);  // Should succeed
    }
}
