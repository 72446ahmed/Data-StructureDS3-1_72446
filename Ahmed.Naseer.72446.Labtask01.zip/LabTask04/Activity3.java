/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask04;

/**
 *
 * @author an_ki
 */
public class Activity3 {

    static class ExtendedCounter {
        private int count;

        // Default constructor
        public ExtendedCounter() {
            count = 0;
        }

        // Overloaded constructor
        public ExtendedCounter(int initialValue) {
            count = initialValue;
        }

        public int getCount() {
            return count;
        }

        public void increment() {
            count++;
        }

        public void decrement() {
            count--;
        }
    }

    public static void main(String[] args) {

        ExtendedCounter c = new ExtendedCounter(10);

        c.increment();
        c.decrement();
        c.decrement();

        System.out.println("Final Count: " + c.getCount());
    }
}