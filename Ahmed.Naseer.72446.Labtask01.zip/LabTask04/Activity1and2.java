/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask04;

/**
 *
 * @author an_ki
 */
public class Activity1and2 {
    class Counter {
        private int count;

        public Counter() {
            count = 0;
        }

        public int getCount() {
            return count;
        }

        public void increment() {
            count++;
        }
    }

    public static void main(String[] args) {
        Activity1and2 activity = new Activity1and2();

        Counter c = activity.new Counter();

        c.increment();
        c.increment();

        System.out.println("Count: " + c.getCount());
    }
}
