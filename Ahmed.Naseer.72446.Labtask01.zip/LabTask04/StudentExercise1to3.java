/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask04;

/**
 *
 * @author an_ki
 */
class Book {
    private String title;
    private String author;
    private double price;

    // Constructor (Exercise 2)
    public Book(String title, String author, double price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }

    // Accessor / Display method (Exercise 2)
    public void displayDetails() {
        System.out.println("Title: " + title + " | Author: " + author + " | Price: $" + price);
    }

    // Mutator / Update method (Exercise 2)
    public void setPrice(double newPrice) {
        this.price = newPrice;
    }

    public double getPrice() {
        return price;
    }
}

public class StudentExercise1to3 {
    public static void main(String[] args) {
        // Exercise 3: Instantiate two distinct Book objects
        Book book1 = new Book("Data Structures in Java", "Goodrich", 49.99);
        Book book2 = new Book("Clean Code", "Robert Martin", 39.95);

        System.out.println("--- Initial Object States ---");
        book1.displayDetails();
        book2.displayDetails();

        // Demonstrating independent state updates
        book1.setPrice(54.99);

        System.out.println("\n--- State After Updating Book 1 Price ---");
        book1.displayDetails();
        book2.displayDetails(); // Remains unchanged
    }
}