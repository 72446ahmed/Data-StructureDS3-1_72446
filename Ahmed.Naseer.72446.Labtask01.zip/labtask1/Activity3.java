/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask1;

/**
 *
 * @author an_ki
 */
public class Activity3 {
 public static void main(String[] args) {
        int x = 10;
        x = x + 5; // x becomes 15
        x++;       // x becomes 16

        System.out.println(x); // Predicted and actual output: 16
    }   
}
