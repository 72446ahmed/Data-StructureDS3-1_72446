/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask1;

/**
 *
 * @author an_ki
 */
public class Exercise1 {
    public static void main(String[] args) {
        String studentName = "Ahmed Naseer";
        int semesterNumber = 3;
        double cgpa = 3.20;

        System.out.println("Name: " + studentName);
        System.out.println("Semester: " + semesterNumber);
        System.out.println("CGPA: " + cgpa);
    }
}
