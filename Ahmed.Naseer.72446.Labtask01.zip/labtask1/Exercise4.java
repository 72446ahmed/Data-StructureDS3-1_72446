/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask1;

/**
 *
 * @author an_ki
 */
public class Exercise4 {
    public static void main(String[] args) {
        /*
         * INTENTIONALLY INVALID IDENTIFIER (Uncomment to see compiler error):
         * int 1stRank = 1; 
         * 
         * NetBeans Compiler Output:
         * "error: not a statement" or "error: <identifier> expected"
         * Reason: Java identifiers cannot begin with a digit.
         */

        // CORRECTED VERSION:
        int firstRank = 1;
        System.out.println("Corrected Identifier Value: " + firstRank);
    }
}
