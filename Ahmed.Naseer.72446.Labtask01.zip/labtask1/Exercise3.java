/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask1;

/**
 *
 * @author an_ki
 */
public class Exercise3 {
    public static void main(String[] args) {
        // Five meaningful student-related variables following Java conventions
        String studentId = "72446";
        int creditHoursCompleted = 45;
        double currentGpa = 3.2;
        char feeStatus = 'P'; // 'P' for Paid
        boolean isEnrolled = true;

        System.out.println("ID: " + studentId);
        System.out.println("Credits: " + creditHoursCompleted);
        System.out.println("GPA: " + currentGpa);
        System.out.println("Fee Status: " + feeStatus);
        System.out.println("Enrolled: " + isEnrolled);
    }
}
