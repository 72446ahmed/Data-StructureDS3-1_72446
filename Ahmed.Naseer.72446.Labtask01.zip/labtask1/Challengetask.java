/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labtask1;

/**
 *
 * @author an_ki
 */
public class Challengetask {
    public static void main(String[] args) {
        // Five variables of different suitable types
        String studentName = "Sarah Connor";
        int studentId = 10482;
        double cgpa = 3.91;
        char letterGrade = 'A';
        boolean isFullTime = true;

        // Display in a formatted, readable output
        System.out.println("===================================");
        System.out.println("     STUDENT PROFILE REPORT       ");
        System.out.println("===================================");
        System.out.println("Name:            " + studentName);
        System.out.println("Student ID:      " + studentId);
        System.out.println("Academic CGPA:   " + cgpa);
        System.out.println("Grade Standing:  " + letterGrade);
        System.out.println("Full-time Status:" + isFullTime);
        System.out.println("===================================");
    }
}
