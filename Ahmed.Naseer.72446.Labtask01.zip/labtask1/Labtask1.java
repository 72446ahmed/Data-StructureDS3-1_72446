/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labtask1;

/**
 *
 * @author an_ki
 */
public class Labtask1 {
    public static void main(String[] args) {
        System.out.println("Welcome to Data Structures Lab");
        
    }
    
}
