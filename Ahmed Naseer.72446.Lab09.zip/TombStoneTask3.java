/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bstdemo;

/**
 *
 * @author an_ki
 */

public class TombStoneTask3 {

    static class Entry {
        int key;
        String value;
        boolean isOccupied;
        boolean isDeleted; // Tombstone marker

        Entry() {
            this.isOccupied = false;
            this.isDeleted = false;
        }
    }

    static class DoubleHashTable {
        private final Entry[] table;
        private final int capacity;

        public DoubleHashTable(int capacity) {
            this.capacity = capacity;
            this.table = new Entry[capacity];
            for (int i = 0; i < capacity; i++) {
                table[i] = new Entry();
            }
        }

        private int h1(int key) {
            return Math.floorMod(key, capacity);
        }

        private int h2(int key) {
            return 5 - Math.floorMod(key, 5);
        }

        private int probeIndex(int key, int i) {
            return Math.floorMod(h1(key) + i * h2(key), capacity);
        }

        public boolean insert(int key, String value) {
            int firstTombstone = -1;

            for (int i = 0; i < capacity; i++) {
                int idx = probeIndex(key, i);
                Entry current = table[idx];

                // Never-occupied slot: stop probing
                if (!current.isOccupied && !current.isDeleted) {
                    int target = (firstTombstone != -1) ? firstTombstone : idx;
                    table[target].key = key;
                    table[target].value = value;
                    table[target].isOccupied = true;
                    table[target].isDeleted = false;
                    System.out.printf("Inserted (%2d, \"%s\") at index %d (h1=%d, h2=%d, i=%d)%n",
                            key, value, target, h1(key), h2(key), i);
                    return true;
                }

                // Record first available tombstone slot
                if (current.isDeleted && firstTombstone == -1) {
                    firstTombstone = idx;
                }

                // Update existing active key
                if (current.isOccupied && !current.isDeleted && current.key == key) {
                    current.value = value;
                    return true;
                }
            }

            if (firstTombstone != -1) {
                table[firstTombstone].key = key;
                table[firstTombstone].value = value;
                table[firstTombstone].isOccupied = true;
                table[firstTombstone].isDeleted = false;
                return true;
            }

            System.out.println("Hash table is full! Could not insert key " + key);
            return false;
        }

        public String search(int key) {
            for (int i = 0; i < capacity; i++) {
                int idx = probeIndex(key, i);
                Entry current = table[idx];

                // Slot has never been occupied -> key does not exist
                if (!current.isOccupied && !current.isDeleted) {
                    return null;
                }

                // Active key match
                if (current.isOccupied && !current.isDeleted && current.key == key) {
                    return current.value;
                }

                // If isDeleted == true (tombstone), continue probing along the chain
            }
            return null;
        }

        public boolean delete(int key) {
            for (int i = 0; i < capacity; i++) {
                int idx = probeIndex(key, i);
                Entry current = table[idx];

                if (!current.isOccupied && !current.isDeleted) {
                    return false;
                }

                if (current.isOccupied && !current.isDeleted && current.key == key) {
                    current.isOccupied = false;
                    current.isDeleted = true; // Tombstone marker
                    current.value = null;
                    return true;
                }
            }
            return false;
        }

        public void displayTable(String title) {
            System.out.println("\n--- " + title + " ---");
            for (int i = 0; i < capacity; i++) {
                Entry e = table[i];
                if (e.isOccupied && !e.isDeleted) {
                    System.out.printf("Index %d : [Key=%2d, Value=\"%s\", isDeleted=false]%n",
                            i, e.key, e.value);
                } else if (e.isDeleted) {
                    System.out.printf("Index %d : <TOMBSTONE | isDeleted=true>%n", i);
                } else {
                    System.out.printf("Index %d : <EMPTY | isOccupied=false, isDeleted=false>%n", i);
                }
            }
            System.out.println("--------------------------------------------------");
        }
    }

    public static void main(String[] args) {
        DoubleHashTable ht = new DoubleHashTable(7);

        System.out.println("=== 1. Inserting Initial Pairs ===");
        ht.insert(12, "Ali");
        ht.insert(19, "Sara");
        ht.insert(26, "Bilal");
        ht.insert(5, "Hina");

        ht.displayTable("Table After Initial Insertions");

        System.out.println("\n=== 2. Deleting Key 19 (Tombstone) ===");
        boolean deleted = ht.delete(19);
        System.out.println("Delete key 19 status: " + (deleted ? "Deleted (Marked as Tombstone)" : "Not Found"));
        ht.displayTable("Table After Deleting Key 19");

        System.out.println("\n=== 3. Searching for Key 26 After Deleting Key 19 ===");
        String result = ht.search(26);
        if (result != null) {
            System.out.println("Verified: Key 26 was found! Value = \"" + result + "\"");
        } else {
            System.out.println("Failed: Key 26 was not found.");
        }
    }
}
