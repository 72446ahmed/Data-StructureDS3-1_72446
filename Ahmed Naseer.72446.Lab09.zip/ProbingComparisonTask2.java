/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bstdemo;

/**
 *
 * @author an_ki
 */


public class ProbingComparisonTask2 {

    enum Mode {
        QUADRATIC,
        DOUBLE_HASHING
    }

    static class HashTable {
        private final Integer[] table;
        private final int capacity;
        private final Mode mode;
        private int totalProbeSteps;

        public HashTable(int capacity, Mode mode) {
            this.capacity = capacity;
            this.mode = mode;
            this.table = new Integer[capacity];
            this.totalProbeSteps = 0;
        }

        private int h1(int key) {
            return Math.floorMod(key, capacity);
        }

        private int h2(int key) {
            return 7 - Math.floorMod(key, 7);
        }

        private int computeIndex(int key, int i) {
            int home = h1(key);
            if (mode == Mode.QUADRATIC) {
                return (home + i * i) % capacity;
            } else {
                return (home + i * h2(key)) % capacity;
            }
        }

        public void insert(int key) {
            int stepsForThisKey = 0;

            for (int i = 0; i < capacity; i++) {
                int index = computeIndex(key, i);
                stepsForThisKey++;
                totalProbeSteps++;

                if (table[index] == null) {
                    table[index] = key;
                    System.out.printf("Inserted %2d at index %2d (h1=%2d, i=%d, steps=%d)%n",
                            key, index, h1(key), i, stepsForThisKey);
                    return;
                } else {
                    System.out.printf("  Probe i=%d for key %2d -> index %2d occupied by %2d%n",
                            i, key, index, table[index]);
                }
            }

            System.out.println("Table is full! Could not insert key " + key);
        }

        public void printTable() {
            System.out.println("\n--- Final Hash Table (" + mode + ", Size = " + capacity + ") ---");
            for (int i = 0; i < capacity; i++) {
                System.out.printf("Index %2d : %s%n", i, (table[i] == null ? "EMPTY" : table[i]));
            }
            System.out.println("Total Probe Steps: " + totalProbeSteps);
            System.out.println("---------------------------------------------------");
        }

        public int getTotalProbeSteps() {
            return totalProbeSteps;
        }
    }

    public static void main(String[] args) {
        int[] keys = {22, 33, 44, 11, 55};

        // 1. Quadratic Probing
        System.out.println("=== QUADRATIC PROBING TRACE ===");
        HashTable quadTable = new HashTable(11, Mode.QUADRATIC);
        for (int key : keys) {
            quadTable.insert(key);
        }
        quadTable.printTable();

        // 2. Double Hashing on a fresh table
        System.out.println("\n=== DOUBLE HASHING TRACE ===");
        HashTable doubleHashTable = new HashTable(11, Mode.DOUBLE_HASHING);
        for (int key : keys) {
            doubleHashTable.insert(key);
        }
        doubleHashTable.printTable();

        // Summary Comparison
        System.out.println("\n=== PROBE STEP COMPARISON ===");
        System.out.println("Quadratic Probing Total Probe Steps : " + quadTable.getTotalProbeSteps());
        System.out.println("Double Hashing Total Probe Steps    : " + doubleHashTable.getTotalProbeSteps());
    }
}