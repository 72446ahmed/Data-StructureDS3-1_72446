/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author an_ki
 */
package bstdemo;

public class LinearProbingTask1 {

    static class HashTable {
        private final Integer[] table;
        private final int capacity;
        private int collisions;

        public HashTable(int capacity) {
            this.capacity = capacity;
            this.table = new Integer[capacity];
            this.collisions = 0;
        }

        private int hash(int key) {
            return Math.floorMod(key, capacity);
        }

        public void insert(int key) {
            int homeIndex = hash(key);
            int i = 0;

            while (i < capacity) {
                int index = (homeIndex + i) % capacity;

                if (table[index] == null) {
                    table[index] = key;
                    System.out.printf("Inserted %2d at index %d (home index %d, probes: %d)%n",
                            key, index, homeIndex, i + 1);
                    return;
                } else {
                    // Collision occurred at index
                    collisions++;
                    System.out.printf("Collision for key %2d at index %d (occupied by %d)%n",
                            key, index, table[index]);
                    i++;
                }
            }

            System.out.println("Hash table is full! Could not insert key " + key);
        }

        public boolean search(int key) {
            int homeIndex = hash(key);

            for (int i = 0; i < capacity; i++) {
                int index = (homeIndex + i) % capacity;

                if (table[index] == null) {
                    return false;
                }
                if (table[index] == key) {
                    return true;
                }
            }
            return false;
        }

        public void printTable() {
            System.out.println("\n--- Final Hash Table Contents (Size = " + capacity + ") ---");
            for (int i = 0; i < capacity; i++) {
                System.out.println("Index " + i + ": " + (table[i] == null ? "EMPTY" : table[i]));
            }
            System.out.println("------------------------------------------");
        }

        public int getCollisions() {
            return collisions;
        }
    }

    public static void main(String[] args) {
        HashTable ht = new HashTable(7);
        int[] keys = {14, 21, 8, 15, 22};

        System.out.println("=== Insertion Trace ===");
        for (int key : keys) {
            ht.insert(key);
        }

        ht.printTable();
        System.out.println("Total Collisions Occurred: " + ht.getCollisions());

        System.out.println("\n=== Search Results ===");
        int[] searchKeys = {15, 99};
        for (int sk : searchKeys) {
            boolean found = ht.search(sk);
            System.out.println("Search key " + sk + ": " + (found ? "Found" : "Not Found"));
        }
    }
}