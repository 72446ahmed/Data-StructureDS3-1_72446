/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bstdemo;

/**
 *
 * @author an_ki
 */

import java.util.Scanner;

public class HashTableEvaluation {

    enum ProbingMode {
        LINEAR,
        QUADRATIC,
        DOUBLE_HASHING
    }

    static class Entry {
        int key;
        String value;
        boolean occupied;
        boolean deleted; // Tombstone flag

        Entry() {
            this.occupied = false;
            this.deleted = false;
        }
    }

    static class OpenAddressHashTable {
        private final Entry[] table;
        private final int capacity;
        private final int primeStep; // Prime < capacity for h2(key)
        private final ProbingMode mode;
        private int size;

        public OpenAddressHashTable(int capacity, ProbingMode mode) {
            this.capacity = capacity;
            this.mode = mode;
            this.table = new Entry[capacity];
            for (int i = 0; i < capacity; i++) {
                table[i] = new Entry();
            }
            this.primeStep = largestPrimeLessThan(capacity);
            this.size = 0;
        }

        private int largestPrimeLessThan(int n) {
            for (int i = n - 1; i >= 2; i--) {
                if (isPrime(i)) {
                    return i;
                }
            }
            return 1;
        }

        private boolean isPrime(int num) {
            if (num < 2) return false;
            for (int i = 2; i * i <= num; i++) {
                if (num % i == 0) return false;
            }
            return true;
        }

        // Primary hash function h1(k)
        private int h1(int key) {
            return Math.floorMod(key, capacity);
        }

        // Secondary hash function h2(k) for Double Hashing
        private int h2(int key) {
            int positiveKey = Math.abs(key);
            return primeStep - (positiveKey % primeStep);
        }

        // Probe index for attempt i (0, 1, 2, ...)
        private int probeIndex(int key, int i) {
            int base = h1(key);
            switch (mode) {
                case LINEAR:
                    return (base + i) % capacity;
                case QUADRATIC:
                    return Math.floorMod(base + i * i, capacity);
                case DOUBLE_HASHING:
                    int step = (i == 0) ? 0 : i * h2(key);
                    return Math.floorMod(base + step, capacity);
                default:
                    return (base + i) % capacity;
            }
        }

        public boolean insert(int key, String value) {
            if (size >= capacity) {
                System.out.println("Hash table is full! Cannot insert key " + key + ".");
                return false;
            }

            int firstTombstoneIndex = -1;

            for (int i = 0; i < capacity; i++) {
                int idx = probeIndex(key, i);
                Entry current = table[idx];

                // Never occupied slot: stop probing
                if (!current.occupied && !current.deleted) {
                    int targetIdx = (firstTombstoneIndex != -1) ? firstTombstoneIndex : idx;
                    table[targetIdx].key = key;
                    table[targetIdx].value = value;
                    table[targetIdx].occupied = true;
                    table[targetIdx].deleted = false;
                    size++;
                    return true;
                }

                // Tombstone slot found
                if (current.deleted && firstTombstoneIndex == -1) {
                    firstTombstoneIndex = idx;
                }

                // Active key already exists: update value
                if (current.occupied && !current.deleted && current.key == key) {
                    current.value = value;
                    return true;
                }
            }

            if (firstTombstoneIndex != -1) {
                table[firstTombstoneIndex].key = key;
                table[firstTombstoneIndex].value = value;
                table[firstTombstoneIndex].occupied = true;
                table[firstTombstoneIndex].deleted = false;
                size++;
                return true;
            }

            System.out.println("Could not find an available slot for key " + key + ".");
            return false;
        }

        public String search(int key) {
            for (int i = 0; i < capacity; i++) {
                int idx = probeIndex(key, i);
                Entry current = table[idx];

                // Empty slot that was never used means key is not present
                if (!current.occupied && !current.deleted) {
                    return null;
                }

                if (current.occupied && !current.deleted && current.key == key) {
                    return current.value;
                }
                // If deleted (tombstone), continue probing
            }
            return null;
        }

        public boolean delete(int key) {
            for (int i = 0; i < capacity; i++) {
                int idx = probeIndex(key, i);
                Entry current = table[idx];

                if (!current.occupied && !current.deleted) {
                    return false;
                }

                if (current.occupied && !current.deleted && current.key == key) {
                    current.occupied = false;
                    current.deleted = true; // Mark as tombstone
                    current.value = null;
                    size--;
                    return true;
                }
            }
            return false;
        }

        public void display() {
            double loadFactor = (double) size / capacity;
            System.out.printf("\n--- Hash Table [%s] | Size: %d/%d | Load Factor (a): %.2f ---%n",
                    mode, size, capacity, loadFactor);
            for (int i = 0; i < capacity; i++) {
                Entry e = table[i];
                if (e.occupied && !e.deleted) {
                    System.out.printf("Index %2d : [Key=%d, Value=\"%s\"]%n", i, e.key, e.value);
                } else if (e.deleted) {
                    System.out.printf("Index %2d : <TOMBSTONE / DELETED>%n", i);
                } else {
                    System.out.printf("Index %2d : <EMPTY>%n", i);
                }
            }
            System.out.println("-------------------------------------------------------------------");
        }
    }

    private static void runAutomatedTestDemo() {
        System.out.println("=== Automated Test Demonstration (All 3 Probing Modes) ===");
        int[][] sampleData = {
            {11, 0}, {22, 1}, {33, 2}, {44, 3}, {55, 4}
        };
        String[] sampleNames = {"Ali", "Sara", "Bilal", "Zara", "Usman"};

        for (ProbingMode mode : ProbingMode.values()) {
            OpenAddressHashTable ht = new OpenAddressHashTable(11, mode);
            for (int j = 0; j < sampleData.length; j++) {
                ht.insert(sampleData[j][0], sampleNames[j]);
            }
            ht.display();

            System.out.println("Search key 33 -> " + ht.search(33));
            System.out.println("Delete key 22 -> " + ht.delete(22));
            System.out.println("Search key 33 after deleting 22 (tombstone check) -> " + ht.search(33));
            ht.display();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Select Collision Resolution Technique:");
        System.out.println("1. Linear Probing");
        System.out.println("2. Quadratic Probing");
        System.out.println("3. Double Hashing");
        System.out.println("4. Run Automated Test Demo for All Modes");
        System.out.print("Enter choice (1-4): ");

        int modeChoice = scanner.hasNextInt() ? scanner.nextInt() : 1;
        scanner.nextLine();

        if (modeChoice == 4) {
            runAutomatedTestDemo();
            scanner.close();
            return;
        }

        ProbingMode selectedMode;
        switch (modeChoice) {
            case 2:
                selectedMode = ProbingMode.QUADRATIC;
                break;
            case 3:
                selectedMode = ProbingMode.DOUBLE_HASHING;
                break;
            default:
                selectedMode = ProbingMode.LINEAR;
                break;
        }

        System.out.print("Enter table capacity (e.g., 11): ");
        int capacity = scanner.hasNextInt() ? scanner.nextInt() : 11;
        scanner.nextLine();
        if (capacity < 3) capacity = 11;

        OpenAddressHashTable hashTable = new OpenAddressHashTable(capacity, selectedMode);
        int option;

        do {
            System.out.println("\n=== Hash Table Menu (" + selectedMode + ") ===");
            System.out.println("1. Insert (int key, String value)");
            System.out.println("2. Search by int key");
            System.out.println("3. Delete by int key (Tombstone)");
            System.out.println("4. Display Hash Table");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");

            while (!scanner.hasNextInt()) {
                System.out.print("Please enter a valid number (1-5): ");
                scanner.next();
            }
            option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1:
                    System.out.print("Enter integer key: ");
                    while (!scanner.hasNextInt()) {
                        System.out.print("Invalid integer key. Enter again: ");
                        scanner.next();
                    }
                    int key = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Enter string value: ");
                    String value = scanner.nextLine();

                    if (hashTable.insert(key, value)) {
                        System.out.println("Inserted/Updated key " + key + ".");
                    }
                    break;

                case 2:
                    System.out.print("Enter integer key to search: ");
                    while (!scanner.hasNextInt()) {
                        System.out.print("Invalid integer key. Enter again: ");
                        scanner.next();
                    }
                    int searchKey = scanner.nextInt();
                    scanner.nextLine();

                    String found = hashTable.search(searchKey);
                    if (found != null) {
                        System.out.println("Found -> Key: " + searchKey + ", Value: \"" + found + "\"");
                    } else {
                        System.out.println("Key " + searchKey + " not found.");
                    }
                    break;

                case 3:
                    System.out.print("Enter integer key to delete: ");
                    while (!scanner.hasNextInt()) {
                        System.out.print("Invalid integer key. Enter again: ");
                        scanner.next();
                    }
                    int delKey = scanner.nextInt();
                    scanner.nextLine();

                    if (hashTable.delete(delKey)) {
                        System.out.println("Key " + delKey + " deleted (marked as tombstone).");
                    } else {
                        System.out.println("Key " + delKey + " not found.");
                    }
                    break;

                case 4:
                    hashTable.display();
                    break;

                case 5:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid option. Choose 1-5.");
            }
        } while (option != 5);

        scanner.close();
    }
}