/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bstdemo;

import java.util.Arrays;

public class MaxHeapTask2 {

    static class MaxHeap {
        private final int[] heap;
        private final int capacity;
        private int size;

        public MaxHeap(int capacity) {
            this.capacity = capacity;
            this.heap = new int[capacity];
            this.size = 0;
        }

        private int parent(int i) {
            return (i - 1) / 2;
        }

        private int leftChild(int i) {
            return 2 * i + 1;
        }

        private int rightChild(int i) {
            return 2 * i + 2;
        }

        private void swap(int i, int j) {
            int temp = heap[i];
            heap[i] = heap[j];
            heap[j] = temp;
        }

        public void insert(int value) {
            if (size >= capacity) {
                throw new IllegalStateException("MaxHeap is full (capacity = " + capacity + ")");
            }
            heap[size] = value;
            int current = size;
            size++;

            // Heapify-up to restore Max Heap property (parent >= children)
            while (current > 0 && heap[current] > heap[parent(current)]) {
                swap(current, parent(current));
                current = parent(current);
            }
        }

        public int peek() {
            if (size == 0) {
                throw new IllegalStateException("MaxHeap is empty");
            }
            return heap[0];
        }

        public int extractMax() {
            if (size == 0) {
                throw new IllegalStateException("MaxHeap is empty");
            }
            int maxValue = heap[0];
            size--;

            if (size > 0) {
                heap[0] = heap[size];
                heapifyDown(0);
            }
            return maxValue;
        }

        private void heapifyDown(int i) {
            int largest = i;
            int left = leftChild(i);
            int right = rightChild(i);

            if (left < size && heap[left] > heap[largest]) {
                largest = left;
            }
            if (right < size && heap[right] > heap[largest]) {
                largest = right;
            }

            if (largest != i) {
                swap(i, largest);
                heapifyDown(largest);
            }
        }

        public int getSize() {
            return size;
        }

        public String arrayToString() {
            return Arrays.toString(Arrays.copyOf(heap, size));
        }
    }

    public static void main(String[] args) {
        MaxHeap maxHeap = new MaxHeap(10);
        int[] scores = {65, 92, 78, 85, 99, 70, 88};

        // 1. Construct Max Heap and insert all 7 quiz scores
        for (int score : scores) {
            maxHeap.insert(score);
        }

        // 2. Display the Max Heap array
        System.out.println("Max Heap array after insertions: " + maxHeap.arrayToString());

        // 3. Display highest score using peek()
        System.out.println("Highest quiz score (peek()): " + maxHeap.peek());

        // 4. Extract maximum element 3 times for Top 3 highest scores
        System.out.println("\n=== Top 3 Highest Scores ===");
        String[] ranks = {"1st", "2nd", "3rd"};
        for (int i = 0; i < 3; i++) {
            int topScore = maxHeap.extractMax();
            System.out.println(ranks[i] + " Highest Score: " + topScore);
        }

        // 5. Display remaining elements in the Max Heap
        System.out.println("\nRemaining elements in Max Heap: " + maxHeap.arrayToString());
        System.out.println("Remaining count: " + maxHeap.getSize());
    }
}