/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bstdemo;

import java.util.Arrays;
import java.util.Scanner;

public class HeapEvaluationTask {

    enum HeapType {
        MIN_HEAP,
        MAX_HEAP
    }

    static class BinaryHeap {
        private final int[] heap;
        private final int capacity;
        private final HeapType type;
        private int size;

        public BinaryHeap(int capacity, HeapType type) {
            if (capacity <= 0) {
                throw new IllegalArgumentException("Capacity must be greater than 0.");
            }
            this.capacity = capacity;
            this.type = type;
            this.heap = new int[capacity];
            this.size = 0;
        }

        private int parent(int i) {
            return (i - 1) / 2;
        }

        private int leftChild(int i) {
            return 2 * i + 1;
        }

        private int rightChild(int i) {
            return 2 * i + 2;
        }

        private boolean shouldSwapUp(int childVal, int parentVal) {
            if (type == HeapType.MIN_HEAP) {
                return childVal < parentVal;
            } else {
                return childVal > parentVal;
            }
        }

        private boolean isBetterRoot(int candidateVal, int currentBestVal) {
            if (type == HeapType.MIN_HEAP) {
                return candidateVal < currentBestVal;
            } else {
                return candidateVal > currentBestVal;
            }
        }

        private void swap(int i, int j) {
            int temp = heap[i];
            heap[i] = heap[j];
            heap[j] = temp;
        }

        public boolean isEmpty() {
            return size == 0;
        }

        public boolean isFull() {
            return size == capacity;
        }

        public int getSize() {
            return size;
        }

        // Insert integer value and perform Heapify-Up
        public boolean insert(int value) {
            if (isFull()) {
                System.out.println("Heap is full (max capacity: " + capacity + "). Cannot insert " + value + ".");
                return false;
            }

            heap[size] = value;
            int current = size;
            size++;

            while (current > 0 && shouldSwapUp(heap[current], heap[parent(current)])) {
                swap(current, parent(current));
                current = parent(current);
            }
            return true;
        }

        // View root element (Min or Max) without removing
        public Integer peek() {
            if (isEmpty()) {
                System.out.println("Heap is empty. No root element to view.");
                return null;
            }
            return heap[0];
        }

        // Extract (delete) root element and perform Heapify-Down
        public Integer extractRoot() {
            if (isEmpty()) {
                System.out.println("Heap is empty. Nothing to extract.");
                return null;
            }

            int rootValue = heap[0];
            size--;

            if (size > 0) {
                heap[0] = heap[size];
                heapifyDown(0);
            }
            return rootValue;
        }

        private void heapifyDown(int i) {
            int target = i;
            int left = leftChild(i);
            int right = rightChild(i);

            if (left < size && isBetterRoot(heap[left], heap[target])) {
                target = left;
            }
            if (right < size && isBetterRoot(heap[right], heap[target])) {
                target = right;
            }

            if (target != i) {
                swap(i, target);
                heapifyDown(target);
            }
        }

        public void display() {
            if (isEmpty()) {
                System.out.println("Heap is currently empty: []");
                return;
            }
            System.out.println("Heap elements (" + type + "): " + Arrays.toString(Arrays.copyOf(heap, size)));
        }
    }

    private static int readInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                int val = scanner.nextInt();
                scanner.nextLine();
                return val;
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.next();
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Heap Application ===");
        System.out.println("1. Min Heap");
        System.out.println("2. Max Heap");
        int heapChoice = readInt(scanner, "Choose Heap type (1 or 2): ");
        HeapType selectedType = (heapChoice == 2) ? HeapType.MAX_HEAP : HeapType.MIN_HEAP;

        int capacity = readInt(scanner, "Enter heap capacity (e.g., 10): ");
        if (capacity <= 0) {
            System.out.println("Invalid capacity. Defaulting to 10.");
            capacity = 10;
        }

        BinaryHeap heap = new BinaryHeap(capacity, selectedType);
        int choice;

        do {
            System.out.println("\n--- " + selectedType + " Menu ---");
            System.out.println("1. Insert an integer value");
            System.out.println("2. View root element (peek)");
            System.out.println("3. Extract (delete) root element");
            System.out.println("4. Display all elements in the heap");
            System.out.println("5. Display current size of the heap");
            System.out.println("6. Exit");

            choice = readInt(scanner, "Enter your choice (1-6): ");

            switch (choice) {
                case 1:
                    int value = readInt(scanner, "Enter integer value to insert: ");
                    if (heap.insert(value)) {
                        System.out.println("Inserted " + value + " into " + selectedType + ".");
                    }
                    break;

                case 2:
                    Integer top = heap.peek();
                    if (top != null) {
                        String label = (selectedType == HeapType.MIN_HEAP) ? "Minimum" : "Maximum";
                        System.out.println("Root element (" + label + "): " + top);
                    }
                    break;

                case 3:
                    Integer removed = heap.extractRoot();
                    if (removed != null) {
                        System.out.println("Extracted (deleted) root value: " + removed);
                    }
                    break;

                case 4:
                    heap.display();
                    break;

                case 5:
                    System.out.println("Current heap size: " + heap.getSize() + " / " + capacity);
                    break;

                case 6:
                    System.out.println("Exiting program...");
                    break;

                default:
                    System.out.println("Invalid choice! Please select an option from 1 to 6.");
            }
        } while (choice != 6);

        scanner.close();
    }
}
