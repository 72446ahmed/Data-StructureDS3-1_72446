/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bstdemo;

public class EmergencyQueueTask3 {

    static class Patient {
        String name;
        int priority; // 1 = Critical ... 5 = Low

        public Patient(String name, int priority) {
            this.name = name;
            this.priority = priority;
        }

        public String getPriorityLabel() {
            switch (priority) {
                case 1: return "Critical";
                case 2: return "Urgent";
                case 3: return "Moderate";
                case 4: return "Normal";
                case 5: return "Low";
                default: return "Unknown";
            }
        }

        @Override
        public String toString() {
            return name + " (Priority " + priority + " - " + getPriorityLabel() + ")";
        }
    }

    static class PatientMinHeap {
        private final Patient[] heap;
        private final int capacity;
        private int size;

        public PatientMinHeap(int capacity) {
            this.capacity = capacity;
            this.heap = new Patient[capacity];
            this.size = 0;
        }

        private int parent(int i) {
            return (i - 1) / 2;
        }

        private int leftChild(int i) {
            return 2 * i + 1;
        }

        private int rightChild(int i) {
            return 2 * i + 2;
        }

        private void swap(int i, int j) {
            Patient temp = heap[i];
            heap[i] = heap[j];
            heap[j] = temp;
        }

        public void insert(Patient patient) {
            if (size >= capacity) {
                throw new IllegalStateException("Emergency queue is full (capacity = " + capacity + ")");
            }
            heap[size] = patient;
            int current = size;
            size++;

            // Heapify-up based on smaller priority number = higher urgency
            while (current > 0 && heap[current].priority < heap[parent(current)].priority) {
                swap(current, parent(current));
                current = parent(current);
            }
        }

        public Patient peek() {
            if (size == 0) {
                throw new IllegalStateException("Emergency queue is empty");
            }
            return heap[0];
        }

        public Patient extractMin() {
            if (size == 0) {
                throw new IllegalStateException("Emergency queue is empty");
            }
            Patient mostUrgent = heap[0];
            size--;

            if (size > 0) {
                heap[0] = heap[size];
                heapifyDown(0);
            }
            return mostUrgent;
        }

        private void heapifyDown(int i) {
            int highestUrgency = i; // smallest priority value
            int left = leftChild(i);
            int right = rightChild(i);

            if (left < size && heap[left].priority < heap[highestUrgency].priority) {
                highestUrgency = left;
            }
            if (right < size && heap[right].priority < heap[highestUrgency].priority) {
                highestUrgency = right;
            }

            if (highestUrgency != i) {
                swap(i, highestUrgency);
                heapifyDown(highestUrgency);
            }
        }

        public void displayWaitingQueue() {
            if (size == 0) {
                System.out.println("No patients currently waiting in the queue.");
                return;
            }
            System.out.println("Remaining patients currently waiting (" + size + "):");
            for (int i = 0; i < size; i++) {
                System.out.println("  - " + heap[i]);
            }
        }
    }

    public static void main(String[] args) {
        PatientMinHeap queue = new PatientMinHeap(10);

        // 1. Insert all 5 sample patients
        queue.insert(new Patient("Ali", 3));
        queue.insert(new Patient("Sara", 1));
        queue.insert(new Patient("Bilal", 4));
        queue.insert(new Patient("Ayesha", 2));
        queue.insert(new Patient("Usman", 5));

        // 2. Display next patient to be treated using peek() without removing
        Patient nextPatient = queue.peek();
        System.out.println("Next patient to be treated (peek()): " + nextPatient.name +
                " [Priority: " + nextPatient.priority + "]");

        // 3. Treat (extract) top 2 most urgent patients one by one
        System.out.println("\n=== Treating Top 2 Most Urgent Patients ===");
        for (int i = 1; i <= 2; i++) {
            Patient treated = queue.extractMin();
            System.out.println("Treating #" + i + ": Name = " + treated.name +
                    ", Priority = " + treated.priority + " (" + treated.getPriorityLabel() + ")");
        }

        // 4. Display remaining patients currently waiting
        System.out.println("\n=== Remaining Queue ===");
        queue.displayWaitingQueue();
    }
}