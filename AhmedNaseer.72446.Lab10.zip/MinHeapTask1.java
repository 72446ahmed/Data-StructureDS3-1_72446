/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author an_ki
 */
package bstdemo;

import java.util.Arrays;

public class MinHeapTask1 {

    static class MinHeap {
        private final int[] heap;
        private final int capacity;
        private int size;

        public MinHeap(int capacity) {
            this.capacity = capacity;
            this.heap = new int[capacity];
            this.size = 0;
        }

        private int parent(int i) {
            return (i - 1) / 2;
        }

        private int leftChild(int i) {
            return 2 * i + 1;
        }

        private int rightChild(int i) {
            return 2 * i + 2;
        }

        private void swap(int i, int j) {
            int temp = heap[i];
            heap[i] = heap[j];
            heap[j] = temp;
        }

        public void insert(int value) {
            if (size >= capacity) {
                throw new IllegalStateException("MinHeap is full (capacity = " + capacity + ")");
            }
            heap[size] = value;
            int current = size;
            size++;

            // Heapify-up to restore Min Heap property
            while (current > 0 && heap[current] < heap[parent(current)]) {
                swap(current, parent(current));
                current = parent(current);
            }
        }

        public int peek() {
            if (size == 0) {
                throw new IllegalStateException("MinHeap is empty");
            }
            return heap[0];
        }

        public int extractMin() {
            if (size == 0) {
                throw new IllegalStateException("MinHeap is empty");
            }
            int minValue = heap[0];
            size--;

            if (size > 0) {
                heap[0] = heap[size];
                heapifyDown(0);
            }
            return minValue;
        }

        private void heapifyDown(int i) {
            int smallest = i;
            int left = leftChild(i);
            int right = rightChild(i);

            if (left < size && heap[left] < heap[smallest]) {
                smallest = left;
            }
            if (right < size && heap[right] < heap[smallest]) {
                smallest = right;
            }

            if (smallest != i) {
                swap(i, smallest);
                heapifyDown(smallest);
            }
        }

        public int getSize() {
            return size;
        }

        public String arrayToString() {
            return Arrays.toString(Arrays.copyOf(heap, size));
        }
    }

    public static void main(String[] args) {
        MinHeap minHeap = new MinHeap(10);
        int[] values = {40, 15, 30, 10, 50, 20, 25};

        // 1. Insert all given values
        for (int val : values) {
            minHeap.insert(val);
        }

        // 2. Display Min Heap array after all insertions
        System.out.println("Min Heap array after insertions: " + minHeap.arrayToString());

        // 3. Display smallest element using peek()
        System.out.println("Smallest element (peek()): " + minHeap.peek());

        // 4. Call extractMin() twice and print removed value + updated array each time
        int removed1 = minHeap.extractMin();
        System.out.println("\n1st extractMin() removed: " + removed1);
        System.out.println("Min Heap array after 1st extraction: " + minHeap.arrayToString());

        int removed2 = minHeap.extractMin();
        System.out.println("\n2nd extractMin() removed: " + removed2);
        System.out.println("Min Heap array after 2nd extraction: " + minHeap.arrayToString());

        // 5. Print final number of elements remaining
        System.out.println("\nFinal number of elements remaining in the heap: " + minHeap.getSize());
    }
}