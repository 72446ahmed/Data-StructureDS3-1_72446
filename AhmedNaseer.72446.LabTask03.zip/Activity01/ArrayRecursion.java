/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity01;

/**
 *
 * @author an_ki
 */
public class ArrayRecursion {
    public static void printArray(int[] arr, int index) {
        if (index == arr.length) {
            System.out.println();
            return;
        }
        System.out.print(arr[index] + " ");
        printArray(arr, index + 1);
    }
    public static int calculateSum(int[] arr, int index) {
        if (index == arr.length) {
            return 0;
        }
        return arr[index] + calculateSum(arr, index + 1);
    }
    public static int recursiveSearch(int[] arr, int target, int index) {
        if (index == arr.length) {
            return -1;
        }
        if (arr[index] == target) {
            return index;
        }
        return recursiveSearch(arr, target, index + 1);
    }

    public static void main(String[] args) {
        int[] numbers = {12, 45, 7, 23, 56, 89, 34};

        System.out.println("--- Recursive Traversal ---");
        System.out.print("Array elements: ");
        printArray(numbers, 0);

        System.out.println("\n--- Recursive Statistics ---");
        int totalSum = calculateSum(numbers, 0);
        System.out.println("Total Sum: " + totalSum);

        System.out.println("\n--- Recursive Search ---");
        int target1 = 23;
        int target2 = 99;

        int index1 = recursiveSearch(numbers, target1, 0);
        int index2 = recursiveSearch(numbers, target2, 0);

        System.out.println("Searching for " + target1 + ": " + (index1 != -1 ? "Found at index " + index1 : "Not found (-1)"));
        System.out.println("Searching for " + target2 + ": " + (index2 != -1 ? "Found at index " + index2 : "Not found (-1)"));
    }
}
