/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity02;

/**
 *
 * @author an_ki
 */
public class MergeSort {

    public static void main(String[] args) {
        int[] arrayForMerge = {64, 25, 12, 22, 11, 90, 34};

        System.out.println("=================================================");
        System.out.println("RUNNING MERGE SORT DEMO");
        System.out.println("=================================================");
        System.out.print("Initial State: ");
        printFullArray(arrayForMerge);
        System.out.println("\n");

        mergeSort(arrayForMerge, 0, arrayForMerge.length - 1);

        System.out.print("\nFinal Sorted Array (Merge Sort): ");
        printFullArray(arrayForMerge);
        System.out.println();
    }
    public static void mergeSort(int[] arr, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;

            System.out.print("Splitting subarray: ");
            printSubarray(arr, left, right);
            System.out.println();

            mergeSort(arr, left, mid);      
            mergeSort(arr, mid + 1, right); 

            merge(arr, left, mid, right);  
        }
    }

    private static void merge(int[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        int[] L = new int[n1];
        int[] R = new int[n2];

        // Manual copy instead of System.arraycopy
        for (int i = 0; i < n1; i++) {
            L[i] = arr[left + i];
        }
        for (int j = 0; j < n2; j++) {
            R[j] = arr[mid + 1 + j];
        }

        System.out.print("   Merging parts -> Left: ");
        printFullArray(L);
        System.out.print(" and Right: ");
        printFullArray(R);
        System.out.println();

        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            arr[k] = L[i];
            i++; 
            k++;
        }
        while (j < n2) {
            arr[k] = R[j];
            j++; 
            k++;
        }

        System.out.print("   Result after merge phase: ");
        printSubarray(arr, left, right);
        System.out.println();
    }

    // ==================== DISPLAY UTILITIES ====================
    private static void printFullArray(int[] arr) {
        System.out.print("[");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + (i < arr.length - 1 ? ", " : ""));
        }
        System.out.print("]");
    }

    private static void printSubarray(int[] arr, int start, int end) {
        System.out.print("[");
        for (int i = start; i <= end; i++) {
            System.out.print(arr[i] + (i < end ? ", " : ""));
        }
        System.out.print("]");
    }
}
