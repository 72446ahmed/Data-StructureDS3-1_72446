/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity02;

/**
 *
 * @author an_ki
 */
public class QuickSort {

    public static void main(String[] args) {
        int[] arrayForQuick = {64, 25, 12, 22, 11, 90, 34};

        System.out.println("=================================================");
        System.out.println("RUNNING QUICK SORT DEMO");
        System.out.println("=================================================");
        System.out.print("Initial State: ");
        printFullArray(arrayForQuick);
        System.out.println("\n");

        quickSort(arrayForQuick, 0, arrayForQuick.length - 1);

        System.out.print("\nFinal Sorted Array (Quick Sort): ");
        printFullArray(arrayForQuick);
        System.out.println();
    }
    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            System.out.print("Processing index range: ");
            printSubarray(arr, low, high);
            System.out.println();

            int pi = partition(arr, low, high); 

            quickSort(arr, low, pi - 1); 
            quickSort(arr, pi + 1, high); 
        }
    }

    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high]; 
        System.out.println("   Selected Pivot Value: [" + pivot + "]");
        int i = (low - 1);

        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        System.out.print("   Current Array State after Partition: ");
        printFullArray(arr);
        System.out.println();
        System.out.println("   Pivot element locked at index location: " + (i + 1));

        return i + 1;
    }
    private static void printFullArray(int[] arr) {
        System.out.print("[");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + (i < arr.length - 1 ? ", " : ""));
        }
        System.out.print("]");
    }

    private static void printSubarray(int[] arr, int start, int end) {
        System.out.print("[");
        for (int i = start; i <= end; i++) {
            System.out.print(arr[i] + (i < end ? ", " : ""));
        }
        System.out.print("]");
    }
}