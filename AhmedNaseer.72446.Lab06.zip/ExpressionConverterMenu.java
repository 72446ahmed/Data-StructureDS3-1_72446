/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author an_ki
 */
import java.util.Scanner;
import java.util.Stack;

public class ExpressionConverterMenu {

    private static int precedence(char ch) {
        switch (ch) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
            default:
                return -1;
        }
    }

    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
    }

    // 1. Infix to Postfix
    public static String infixToPostfix(String expression) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            if (Character.isWhitespace(c)) continue;

            if (Character.isLetterOrDigit(c)) {
                result.append(c).append(" ");
            } else if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop()).append(" ");
                }
                if (!stack.isEmpty() && stack.peek() == '(') {
                    stack.pop();
                }
            } else if (isOperator(c)) {
                while (!stack.isEmpty() && precedence(c) <= precedence(stack.peek())) {
                    result.append(stack.pop()).append(" ");
                }
                stack.push(c);
            }
        }

        while (!stack.isEmpty()) {
            if (stack.peek() == '(') return "Invalid Expression";
            result.append(stack.pop()).append(" ");
        }

        return result.toString().trim();
    }

    // 2. Postfix to Infix
    public static String postfixToInfix(String expression) {
        Stack<String> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            if (Character.isWhitespace(c)) continue;

            if (Character.isLetterOrDigit(c)) {
                stack.push(String.valueOf(c));
            } else if (isOperator(c)) {
                if (stack.size() < 2) return "Invalid Postfix Expression";
                String op2 = stack.pop();
                String op1 = stack.pop();
                stack.push("(" + op1 + " " + c + " " + op2 + ")");
            }
        }

        return stack.size() == 1 ? stack.pop() : "Invalid Postfix Expression";
    }

    // 3. Infix to Prefix
    public static String infixToPrefix(String expression) {
        StringBuilder reversed = new StringBuilder();
        for (int i = expression.length() - 1; i >= 0; i--) {
            char c = expression.charAt(i);
            if (c == '(') reversed.append(')');
            else if (c == ')') reversed.append('(');
            else reversed.append(c);
        }

        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < reversed.length(); i++) {
            char c = reversed.charAt(i);

            if (Character.isWhitespace(c)) continue;

            if (Character.isLetterOrDigit(c)) {
                result.append(c).append(" ");
            } else if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop()).append(" ");
                }
                if (!stack.isEmpty() && stack.peek() == '(') stack.pop();
            } else if (isOperator(c)) {
                while (!stack.isEmpty() && precedence(c) < precedence(stack.peek())) {
                    result.append(stack.pop()).append(" ");
                }
                stack.push(c);
            }
        }

        while (!stack.isEmpty()) {
            result.append(stack.pop()).append(" ");
        }

        return result.reverse().toString().trim();
    }

    // 4. Prefix to Infix
    public static String prefixToInfix(String expression) {
        Stack<String> stack = new Stack<>();

        for (int i = expression.length() - 1; i >= 0; i--) {
            char c = expression.charAt(i);

            if (Character.isWhitespace(c)) continue;

            if (Character.isLetterOrDigit(c)) {
                stack.push(String.valueOf(c));
            } else if (isOperator(c)) {
                if (stack.size() < 2) return "Invalid Prefix Expression";
                String op1 = stack.pop();
                String op2 = stack.pop();
                stack.push("(" + op1 + " " + c + " " + op2 + ")");
            }
        }

        return stack.size() == 1 ? stack.pop() : "Invalid Prefix Expression";
    }

    // 5. Prefix to Postfix
    public static String prefixToPostfix(String expression) {
        Stack<String> stack = new Stack<>();

        for (int i = expression.length() - 1; i >= 0; i--) {
            char c = expression.charAt(i);

            if (Character.isWhitespace(c)) continue;

            if (Character.isLetterOrDigit(c)) {
                stack.push(String.valueOf(c));
            } else if (isOperator(c)) {
                if (stack.size() < 2) return "Invalid Prefix Expression";
                String op1 = stack.pop();
                String op2 = stack.pop();
                stack.push(op1 + " " + op2 + " " + c);
            }
        }

        return stack.size() == 1 ? stack.pop() : "Invalid Prefix Expression";
    }

    // 6. Postfix to Prefix
    public static String postfixToPrefix(String expression) {
        Stack<String> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            if (Character.isWhitespace(c)) continue;

            if (Character.isLetterOrDigit(c)) {
                stack.push(String.valueOf(c));
            } else if (isOperator(c)) {
                if (stack.size() < 2) return "Invalid Postfix Expression";
                String op2 = stack.pop();
                String op1 = stack.pop();
                stack.push(c + " " + op1 + " " + op2);
            }
        }

        return stack.size() == 1 ? stack.pop() : "Invalid Postfix Expression";
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n========== EXPRESSION CONVERSION ==========");
            System.out.println("1. Infix to Postfix");
            System.out.println("2. Postfix to Infix");
            System.out.println("3. Infix to Prefix");
            System.out.println("4. Prefix to Infix");
            System.out.println("5. Prefix to Postfix");
            System.out.println("6. Postfix to Prefix");
            System.out.println("7. Exit");
            System.out.print("\nEnter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear buffer

            if (choice == 7) {
                System.out.println("Exiting program.");
                break;
            }

            System.out.print("Enter Expression: ");
            String inputExpr = scanner.nextLine();
            System.out.println("\nOriginal Expression:\n" + inputExpr);

            String result = "";
            switch (choice) {
                case 1:
                    result = infixToPostfix(inputExpr);
                    System.out.println("Postfix Expression:\n" + result);
                    break;
                case 2:
                    result = postfixToInfix(inputExpr);
                    System.out.println("Infix Expression:\n" + result);
                    break;
                case 3:
                    result = infixToPrefix(inputExpr);
                    System.out.println("Prefix Expression:\n" + result);
                    break;
                case 4:
                    result = prefixToInfix(inputExpr);
                    System.out.println("Infix Expression:\n" + result);
                    break;
                case 5:
                    result = prefixToPostfix(inputExpr);
                    System.out.println("Postfix Expression:\n" + result);
                    break;
                case 6:
                    result = postfixToPrefix(inputExpr);
                    System.out.println("Prefix Expression:\n" + result);
                    break;
                default:
                    System.out.println("Invalid choice! Please select 1-7.");
            }
        }
        scanner.close();
    }
}
