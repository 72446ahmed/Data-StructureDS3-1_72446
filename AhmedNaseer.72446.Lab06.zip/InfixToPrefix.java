/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author an_ki
 */
import java.util.Scanner;
import java.util.Stack;

public class InfixToPrefix {

    // Helper method to determine operator precedence
    private static int precedence(char ch) {
        switch (ch) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
            default:
                return -1;
        }
    }

    // Method to convert Infix expression to Prefix notation
    public static String infixToPrefix(String expression) {
        // Step 1: Reverse the infix expression
        StringBuilder reversedInfix = new StringBuilder();
        for (int i = expression.length() - 1; i >= 0; i--) {
            char c = expression.charAt(i);
            
            // Step 2: Swap parentheses during reversal
            if (c == '(') {
                reversedInfix.append(')');
            } else if (c == ')') {
                reversedInfix.append('(');
            } else {
                reversedInfix.append(c);
            }
        }

        // Step 3: Get Postfix of the reversed infix expression
        String postfix = infixToPostfixForPrefix(reversedInfix.toString());

        // Step 4: Reverse the postfix result to get final Prefix notation
        StringBuilder prefix = new StringBuilder();
        for (int i = postfix.length() - 1; i >= 0; i--) {
            prefix.append(postfix.charAt(i));
        }

        return prefix.toString().trim();
    }

    // Postfix conversion logic optimized for Prefix pipeline
    private static String infixToPostfixForPrefix(String exp) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < exp.length(); i++) {
            char c = exp.charAt(i);

            if (Character.isWhitespace(c)) {
                continue;
            }

            // Operands added directly to output
            if (Character.isLetterOrDigit(c)) {
                result.append(c).append(" ");
            }
            // Open parenthesis pushed to stack
            else if (c == '(') {
                stack.push(c);
            }
            // Close parenthesis pops until '(' is found
            else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop()).append(" ");
                }
                if (!stack.isEmpty() && stack.peek() == '(') {
                    stack.pop();
                }
            }
            // Operators
            else {
                // Note: Strictly less-than for right-to-left associativity alignment
                while (!stack.isEmpty() && precedence(c) < precedence(stack.peek())) {
                    result.append(stack.pop()).append(" ");
                }
                stack.push(c);
            }
        }

        // Pop remaining operators
        while (!stack.isEmpty()) {
            result.append(stack.pop()).append(" ");
        }

        return result.toString();
    }

    public static void main(String[] args) {
        // Test expressions
        String expr1 = "A + B * C";
        String expr2 = "( A + B ) * C";
        String expr3 = "A + B * C - D / E";

        System.out.println("==========================================");
        System.out.println("      INFIX TO PREFIX CONVERSION LAB      ");
        System.out.println("==========================================");

        System.out.println("Test 1:");
        System.out.println("Infix:  " + expr1);
        System.out.println("Prefix: " + infixToPrefix(expr1));
        System.out.println();

        System.out.println("Test 2:");
        System.out.println("Infix:  " + expr2);
        System.out.println("Prefix: " + infixToPrefix(expr2));
        System.out.println();

        System.out.println("Test 3:");
        System.out.println("Infix:  " + expr3);
        System.out.println("Prefix: " + infixToPrefix(expr3));
        System.out.println();

        // Custom user input test
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter custom Infix expression: ");
        String userInput = scanner.nextLine();
        System.out.println("Prefix Output: " + infixToPrefix(userInput));

        scanner.close();
    }
}