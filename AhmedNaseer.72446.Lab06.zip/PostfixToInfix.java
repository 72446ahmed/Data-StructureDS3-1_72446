/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author an_ki
 */
import java.util.Scanner;
import java.util.Stack;

public class PostfixToInfix {

    // Helper method to check if a character is an operator
    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
    }

    // Method to convert Postfix expression to Infix expression
    public static String postfixToInfix(String expression) {
        Stack<String> stack = new Stack<>();

        // Iterate through expression left to right
        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            // Skip whitespace characters
            if (Character.isWhitespace(c)) {
                continue;
            }

            // 1. If symbol is an operand, push it onto the stack as a String
            if (Character.isLetterOrDigit(c)) {
                stack.push(String.valueOf(c));
            } 
            // 2. If symbol is an operator
            else if (isOperator(c)) {
                // Check if at least two operands are present on the stack
                if (stack.size() < 2) {
                    return "Invalid Postfix Expression";
                }

                // Pop top operand (op1) and second operand (op2)
                String op1 = stack.pop();
                String op2 = stack.pop();

                // Place operator between them and enclose in parentheses
                String infixPart = "(" + op2 + " " + c + " " + op1 + ")";

                // Push resulting expression back onto the stack
                stack.push(infixPart);
            }
        }

        // Final stack element is the complete Infix expression
        if (stack.size() == 1) {
            return stack.pop();
        } else {
            return "Invalid Postfix Expression";
        }
    }

    public static void main(String[] args) {
        // Test expressions
        String postfix1 = "A B C * +";
        String postfix2 = "A B + C *";
        String postfix3 = "A B C * + D E / -";

        System.out.println("==========================================");
        System.out.println("     POSTFIX TO INFIX CONVERSION LAB      ");
        System.out.println("==========================================");

        System.out.println("Test 1:");
        System.out.println("Postfix: " + postfix1);
        System.out.println("Infix:   " + postfixToInfix(postfix1));
        System.out.println();

        System.out.println("Test 2:");
        System.out.println("Postfix: " + postfix2);
        System.out.println("Infix:   " + postfixToInfix(postfix2));
        System.out.println();

        System.out.println("Test 3:");
        System.out.println("Postfix: " + postfix3);
        System.out.println("Infix:   " + postfixToInfix(postfix3));
        System.out.println();

        // Custom user input test
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter custom Postfix expression: ");
        String userInput = scanner.nextLine();
        System.out.println("Infix Output: " + postfixToInfix(userInput));

        scanner.close();
    }
}