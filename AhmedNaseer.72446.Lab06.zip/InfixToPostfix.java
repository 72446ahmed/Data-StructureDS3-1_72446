/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author an_ki
 */
import java.util.Scanner;
import java.util.Stack;

public class InfixToPostfix {

    // Helper method to determine operator precedence
    private static int precedence(char ch) {
        switch (ch) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
            default:
                return -1;
        }
    }

    // Method to convert Infix expression to Postfix notation
    public static String infixToPostfix(String expression) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            // Skip whitespace characters
            if (Character.isWhitespace(c)) {
                continue;
            }

            // 1. If character is an operand (letter or digit), add directly to output
            if (Character.isLetterOrDigit(c)) {
                result.append(c).append(" ");
            }
            // 2. If '(', push onto stack
            else if (c == '(') {
                stack.push(c);
            }
            // 3. If ')', pop until '(' is encountered
            else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop()).append(" ");
                }
                if (!stack.isEmpty() && stack.peek() == '(') {
                    stack.pop(); // Remove '(' from stack
                }
            }
            // 4. If an operator (+, -, *, /, ^)
            else {
                while (!stack.isEmpty() && precedence(c) <= precedence(stack.peek())) {
                    result.append(stack.pop()).append(" ");
                }
                stack.push(c);
            }
        }

        // 5. Pop all remaining operators from the stack
        while (!stack.isEmpty()) {
            if (stack.peek() == '(') {
                return "Invalid Expression";
            }
            result.append(stack.pop()).append(" ");
        }

        return result.toString().trim();
    }

    public static void main(String[] args) {
        // Required test expressions
        String expr1 = "A + B * C";
        String expr2 = "( A + B ) * C";
        String expr3 = "A + B * C - D / E";

        System.out.println("==========================================");
        System.out.println("     INFIX TO POSTFIX CONVERSION LAB      ");
        System.out.println("==========================================");

        System.out.println("Test 1:");
        System.out.println("Infix:   " + expr1);
        System.out.println("Postfix: " + infixToPostfix(expr1));
        System.out.println();

        System.out.println("Test 2:");
        System.out.println("Infix:   " + expr2);
        System.out.println("Postfix: " + infixToPostfix(expr2));
        System.out.println();

        System.out.println("Test 3:");
        System.out.println("Infix:   " + expr3);
        System.out.println("Postfix: " + infixToPostfix(expr3));
        System.out.println();

        // Dynamic user input test
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter custom Infix expression: ");
        String userInput = scanner.nextLine();
        System.out.println("Postfix Output: " + infixToPostfix(userInput));
        
        scanner.close();
    }
}