/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author an_ki
 */
import java.util.Scanner;
import java.util.Stack;

public class PostfixToPrefix {

    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
    }

    public static String postfixToPrefix(String expression) {
        Stack<String> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            if (Character.isWhitespace(c)) {
                continue;
            }

            if (Character.isLetterOrDigit(c)) {
                stack.push(String.valueOf(c));
            } else if (isOperator(c)) {
                if (stack.size() < 2) {
                    return "Invalid Postfix Expression";
                }

                String op2 = stack.pop();
                String op1 = stack.pop();

                String prefixPart = c + " " + op1 + " " + op2;
                stack.push(prefixPart);
            }
        }

        return stack.size() == 1 ? stack.pop() : "Invalid Postfix Expression";
    }

    public static void main(String[] args) {
        String postfix1 = "A B C * +";
        String postfix2 = "A B + C *";

        System.out.println("==========================================");
        System.out.println("     POSTFIX TO PREFIX CONVERSION LAB     ");
        System.out.println("==========================================");

        System.out.println("Test 1:");
        System.out.println("Postfix: " + postfix1);
        System.out.println("Prefix:  " + postfixToPrefix(postfix1));
        System.out.println();

        System.out.println("Test 2:");
        System.out.println("Postfix: " + postfix2);
        System.out.println("Prefix:  " + postfixToPrefix(postfix2));
        System.out.println();

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter custom Postfix expression: ");
        String userInput = scanner.nextLine();
        System.out.println("Prefix Output: " + postfixToPrefix(userInput));

        scanner.close();
    }
}