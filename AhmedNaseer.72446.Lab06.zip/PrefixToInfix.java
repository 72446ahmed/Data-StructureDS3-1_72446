/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author an_ki
 */
import java.util.Scanner;
import java.util.Stack;

public class PrefixToInfix {

    // Helper method to check if a character is an operator
    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
    }

    // Method to convert Prefix expression to Infix expression
    public static String prefixToInfix(String expression) {
        Stack<String> stack = new Stack<>();

        // Read expression from right to left
        for (int i = expression.length() - 1; i >= 0; i--) {
            char c = expression.charAt(i);

            // Skip whitespace characters
            if (Character.isWhitespace(c)) {
                continue;
            }

            // 1. If symbol is an operand, push it onto the stack
            if (Character.isLetterOrDigit(c)) {
                stack.push(String.valueOf(c));
            }
            // 2. If symbol is an operator
            else if (isOperator(c)) {
                // Check if at least two operands exist on the stack
                if (stack.size() < 2) {
                    return "Invalid Prefix Expression";
                }

                // Pop first operand (op1) and second operand (op2)
                String op1 = stack.pop();
                String op2 = stack.pop();

                // Enclose operator between op1 and op2 in parentheses
                String infixPart = "(" + op1 + " " + c + " " + op2 + ")";

                // Push resulting string back onto the stack
                stack.push(infixPart);
            }
        }

        // The final element remaining on the stack is the Infix expression
        if (stack.size() == 1) {
            return stack.pop();
        } else {
            return "Invalid Prefix Expression";
        }
    }

    public static void main(String[] args) {
        // Test expressions
        String prefix1 = "+ A * B C";
        String prefix2 = "* + A B C";
        String prefix3 = "- + A * B C / D E";

        System.out.println("==========================================");
        System.out.println("      PREFIX TO INFIX CONVERSION LAB      ");
        System.out.println("==========================================");

        System.out.println("Test 1:");
        System.out.println("Prefix: " + prefix1);
        System.out.println("Infix:  " + prefixToInfix(prefix1));
        System.out.println();

        System.out.println("Test 2:");
        System.out.println("Prefix: " + prefix2);
        System.out.println("Infix:  " + prefixToInfix(prefix2));
        System.out.println();

        System.out.println("Test 3:");
        System.out.println("Prefix: " + prefix3);
        System.out.println("Infix:  " + prefixToInfix(prefix3));
        System.out.println();

        // Custom user input test
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter custom Prefix expression: ");
        String userInput = scanner.nextLine();
        System.out.println("Infix Output: " + prefixToInfix(userInput));

        scanner.close();
    }
}
