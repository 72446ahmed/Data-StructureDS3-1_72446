/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity01;

/**
 *
 * @author an_ki
 */
import java.util.Scanner;

public class LinearSearch {
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i; 
            }
        }
        return -1; 
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int[] linearArray = {45, 12, 78, 34, 23, 89, 56};

        System.out.print("Enter a target value to search for in Linear Search array: ");
        int target = input.nextInt();

        System.out.println("\n==========================================");
        System.out.println("          LINEAR SEARCH RESULT            ");
        System.out.println("==========================================");
        System.out.println("Target Value: " + target);

        int result = linearSearch(linearArray, target);

        if (result != -1) {
            System.out.println("Result: Found at index position " + result);
        } else {
            System.out.println("Result: Target value not found (-1)");
        }
        System.out.println("==========================================");
    }
}