/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab07;

/**
 *
 * @author an_ki
 */
public class UndirectedGraphOperations {
    private int vertices;
    private int[][] adjMatrix;

    // Constructor to initialize the graph
    public UndirectedGraphOperations(int vertices) {
        this.vertices = vertices;
        adjMatrix = new int[vertices][vertices];
    }

    // Helper method to validate vertex bounds
    private boolean isValidVertex(int v) {
        return v >= 0 && v < vertices;
    }

    // 1. Add an edge between two vertices (updates both [u][v] and [v][u])
    public void addEdge(int src, int dest) {
        if (isValidVertex(src) && isValidVertex(dest)) {
            adjMatrix[src][dest] = 1;
            adjMatrix[dest][src] = 1;
        } else {
            System.out.println("Error: Invalid vertex index.");
        }
    }

    // 2. Remove an existing edge (updates both [u][v] and [v][u] to 0)
    public void removeEdge(int src, int dest) {
        if (isValidVertex(src) && isValidVertex(dest)) {
            adjMatrix[src][dest] = 0;
            adjMatrix[dest][src] = 0;
        } else {
            System.out.println("Error: Invalid vertex index.");
        }
    }

    // 3. Check whether an edge exists between two vertices
    public boolean hasEdge(int src, int dest) {
        if (isValidVertex(src) && isValidVertex(dest)) {
            return adjMatrix[src][dest] == 1;
        }
        return false;
    }

    // 4. Calculate the degree of a specified vertex
    public int getDegree(int vertex) {
        if (!isValidVertex(vertex)) {
            System.out.println("Error: Invalid vertex index.");
            return -1;
        }
        int degree = 0;
        for (int j = 0; j < vertices; j++) {
            degree += adjMatrix[vertex][j];
        }
        return degree;
    }

    // 5. Display the adjacency matrix
    public void displayMatrix() {
        System.out.println("Adjacency Matrix:");
        System.out.print("   ");
        for (int i = 0; i < vertices; i++) {
            System.out.print(i + " ");
        }
        System.out.println();

        for (int i = 0; i < vertices; i++) {
            System.out.print(i + "  ");
            for (int j = 0; j < vertices; j++) {
                System.out.print(adjMatrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        int V = 5;
        UndirectedGraphOperations graph = new UndirectedGraphOperations(V);

        // Initial Edges from Task 1
        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 2);
        graph.addEdge(1, 3);
        graph.addEdge(3, 4);

        System.out.println("--- Initial Graph State ---");
        graph.displayMatrix();

        // Perform Task 2 Operations
        System.out.println("\n[Operation] Adding edge between 2 and 4...");
        graph.addEdge(2, 4);

        System.out.println("[Operation] Removing edge between 0 and 1...");
        graph.removeEdge(0, 1);

        // Display updated matrix
        System.out.println("\n--- Updated Graph State ---");
        graph.displayMatrix();

        // Check edge existence
        System.out.println("\n--- Edge Existence Checks ---");
        System.out.println("Edge between 2 and 4 exists? " + graph.hasEdge(2, 4));
        System.out.println("Edge between 0 and 1 exists? " + graph.hasEdge(0, 1));

        // Calculate and display degree of a specific vertex
        int targetVertex = 1;
        System.out.println("\n--- Degree Query ---");
        System.out.println("Degree of vertex " + targetVertex + ": " + graph.getDegree(targetVertex));
    }
}