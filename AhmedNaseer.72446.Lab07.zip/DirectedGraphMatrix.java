/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab07;

/**
 *
 * @author an_ki
 */
public class DirectedGraphMatrix {
    private int vertices;
    private int[][] adjMatrix;

    // Constructor to initialize directed graph
    public DirectedGraphMatrix(int vertices) {
        this.vertices = vertices;
        adjMatrix = new int[vertices][vertices];
    }

    // Add a directed edge from src to dest (NOT symmetric)
    public void addEdge(int src, int dest) {
        if (src >= 0 && src < vertices && dest >= 0 && dest < vertices) {
            adjMatrix[src][dest] = 1;
        } else {
            System.out.println("Error: Invalid vertex index.");
        }
    }

    // Calculate out-degree: sum of the row values
    public int getOutDegree(int vertex) {
        int outDegree = 0;
        for (int j = 0; j < vertices; j++) {
            outDegree += adjMatrix[vertex][j];
        }
        return outDegree;
    }

    // Calculate in-degree: sum of the column values
    public int getInDegree(int vertex) {
        int inDegree = 0;
        for (int i = 0; i < vertices; i++) {
            inDegree += adjMatrix[i][vertex];
        }
        return inDegree;
    }

    // Display the adjacency matrix
    public void displayMatrix() {
        System.out.println("Adjacency Matrix (Directed):");
        System.out.print("   ");
        for (int i = 0; i < vertices; i++) {
            System.out.print(i + " ");
        }
        System.out.println();

        for (int i = 0; i < vertices; i++) {
            System.out.print(i + "  ");
            for (int j = 0; j < vertices; j++) {
                System.out.print(adjMatrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    // Display in-degrees and out-degrees for all vertices
    public void displayDegrees() {
        System.out.println("\nVertex Degrees (In-Degree & Out-Degree):");
        for (int i = 0; i < vertices; i++) {
            System.out.println("Vertex " + i + " -> In-Degree: " + getInDegree(i) + ", Out-Degree: " + getOutDegree(i));
        }
    }

    public static void main(String[] args) {
        int V = 5; // Vertices numbered 0 to 4
        DirectedGraphMatrix graph = new DirectedGraphMatrix(V);

        // Adding specified directed edges
        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 2);
        graph.addEdge(2, 3);
        graph.addEdge(3, 1);

        // Display results
        graph.displayMatrix();
        graph.displayDegrees();
    }
}