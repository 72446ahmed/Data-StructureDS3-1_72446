/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab07;

/**
 *
 * @author an_ki
 */
import java.util.InputMismatchException;
import java.util.Scanner;

public class UniversityNetwork {
    private int vertices = 5;
    private int[][] adjMatrix;

    // Constructor to initialize departments (0 to 4)
    public UniversityNetwork() {
        adjMatrix = new int[vertices][vertices];
    }

    // Helper to validate department index
    private boolean isValidVertex(int v) {
        return v >= 0 && v < vertices;
    }

    // 1. Add a bidirectional communication link between two departments
    public void addEdge(int src, int dest) {
        if (isValidVertex(src) && isValidVertex(dest)) {
            if (src == dest) {
                System.out.println("[Warning]: A department cannot link directly to itself.");
                return;
            }
            adjMatrix[src][dest] = 1;
            adjMatrix[dest][src] = 1;
            System.out.println("Success: Bidirectional link established between Department " + src + " and Department " + dest);
        } else {
            System.out.println("[Error]: Invalid department ID! Valid IDs are between 0 and 4.");
        }
    }

    // 2. Check whether two departments are directly connected
    public boolean isConnected(int src, int dest) {
        if (isValidVertex(src) && isValidVertex(dest)) {
            return adjMatrix[src][dest] == 1;
        }
        System.out.println("[Error]: Invalid department ID!");
        return false;
    }

    // 3. Calculate the degree (total active links) of a selected department
    public int getDegree(int dept) {
        if (!isValidVertex(dept)) {
            System.out.println("[Error]: Invalid department ID!");
            return -1;
        }
        int degree = 0;
        for (int j = 0; j < vertices; j++) {
            degree += adjMatrix[dept][j];
        }
        return degree;
    }

    // 4. Display the adjacency matrix formatted for departments
    public void displayMatrix() {
        System.out.println("\n--- University Communication Adjacency Matrix ---");
        System.out.print("     ");
        for (int i = 0; i < vertices; i++) {
            System.out.print("Dept " + i + " ");
        }
        System.out.println();

        for (int i = 0; i < vertices; i++) {
            System.out.print("Dept " + i + " ");
            for (int j = 0; j < vertices; j++) {
                System.out.print("   " + adjMatrix[i][j] + "   ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UniversityNetwork network = new UniversityNetwork();

        while (true) {
            try {
                System.out.println("\n========== UNIVERSITY DEPARTMENT NETWORK ==========");
                System.out.println("1. Add Communication Link");
                System.out.println("2. Display Adjacency Matrix");
                System.out.println("3. Check Direct Connection");
                System.out.println("4. View Department Link Count (Degree)");
                System.out.println("5. Exit");
                System.out.print("\nEnter your choice (1-5): ");

                int choice = scanner.nextInt();

                if (choice == 5) {
                    System.out.println("Exiting network manager application.");
                    break;
                }

                switch (choice) {
                    case 1:
                        System.out.print("Enter first department ID (0-4): ");
                        int u = scanner.nextInt();
                        System.out.print("Enter second department ID (0-4): ");
                        int v = scanner.nextInt();
                        network.addEdge(u, v);
                        break;

                    case 2:
                        network.displayMatrix();
                        break;

                    case 3:
                        System.out.print("Enter first department ID (0-4): ");
                        int c1 = scanner.nextInt();
                        System.out.print("Enter second department ID (0-4): ");
                        int c2 = scanner.nextInt();
                        boolean connected = network.isConnected(c1, c2);
                        if (connected) {
                            System.out.println("Result: Departments " + c1 + " and " + c2 + " are DIRECTLY connected.");
                        } else {
                            System.out.println("Result: Departments " + c1 + " and " + c2 + " are NOT directly connected.");
                        }
                        break;

                    case 4:
                        System.out.print("Enter department ID to inspect (0-4): ");
                        int dept = scanner.nextInt();
                        int degree = network.getDegree(dept);
                        if (degree != -1) {
                            System.out.println("Result: Department " + dept + " has " + degree + " active direct communication links.");
                        }
                        break;

                    default:
                        System.out.println("[Warning]: Invalid option! Please select a choice between 1 and 5.");
                }
            } catch (InputMismatchException e) {
                System.out.println("[Input Error]: Please enter valid numeric options only.");
                scanner.nextLine(); // Clear invalid buffer
            }
        }
        scanner.close();
    }
}