/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab07;

/**
 *
 * @author an_ki
 */
public class UndirectedGraphMatrix {
    private int vertices;
    private int[][] adjMatrix;

    // Constructor to initialize the graph with a given number of vertices
    public UndirectedGraphMatrix(int vertices) {
        this.vertices = vertices;
        adjMatrix = new int[vertices][vertices];
    }

    // Method to add an edge for an undirected graph
    public void addEdge(int src, int dest) {
        adjMatrix[src][dest] = 1;
        adjMatrix[dest][src] = 1; // Symmetric for undirected graphs
    }

    // Method to display the adjacency matrix
    public void displayMatrix() {
        System.out.println("Adjacency Matrix:");
        System.out.print("   ");
        for (int i = 0; i < vertices; i++) {
            System.out.print(i + " ");
        }
        System.out.println();

        for (int i = 0; i < vertices; i++) {
            System.out.print(i + "  ");
            for (int j = 0; j < vertices; j++) {
                System.out.print(adjMatrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    // Method to calculate and display the degree of each vertex
    public void displayDegrees() {
        System.out.println("\nVertex Degrees:");
        for (int i = 0; i < vertices; i++) {
            int degree = 0;
            for (int j = 0; j < vertices; j++) {
                degree += adjMatrix[i][j]; // Sum of the row represents the degree
            }
            System.out.println("Degree of vertex " + i + ": " + degree);
        }
    }

    public static void main(String[] args) {
        int V = 5; // Vertices numbered from 0 to 4
        UndirectedGraphMatrix graph = new UndirectedGraphMatrix(V);

        // Adding specified edges
        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 2);
        graph.addEdge(1, 3);
        graph.addEdge(3, 4);

        // Display matrix and degrees
        graph.displayMatrix();
        graph.displayDegrees();
    }
}
